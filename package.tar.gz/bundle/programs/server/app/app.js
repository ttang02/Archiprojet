var require = meteorInstall({"lib":{"routers":{"logged":{"admin":{"typeAU":{"route.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/routers/logged/admin/typeAU/route.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Router.route('/admin/typeau/', {                                                                                       // 1
	name: 'admintypeAU',                                                                                                  // 2
	template: 'admintypeAU',                                                                                              // 3
	title: 'typeAU',                                                                                                      // 4
	parent: 'adminBase',                                                                                                  // 5
	onBeforeAction: function () {                                                                                         // 6
		function onBeforeAction() {                                                                                          // 6
			var currentUserId = Meteor.userId();                                                                                // 7
			var currentUser = Meteor.users.findOne({ _id: currentUserId });                                                     // 8
			if (currentUser) {                                                                                                  // 9
				var currentUserRole = currentUser.profile.role;                                                                    // 10
                                                                                                                       //
				if (currentUserRole === 'admin') {                                                                                 // 12
					this.next();                                                                                                      // 13
				} else {                                                                                                           // 14
					Materialize.toast('Vous n\'avez pas l\'autorisation pour accéder à cette page !', 4000);                          // 16
					Router.go("login");                                                                                               // 17
				}                                                                                                                  // 18
			} else {                                                                                                            // 19
				Materialize.toast('Vous n\'avez pas l\'autorisation pour accéder à cette page !', 4000);                           // 21
				Router.go("login");                                                                                                // 22
			}                                                                                                                   // 23
		}                                                                                                                    // 24
                                                                                                                       //
		return onBeforeAction;                                                                                               // 6
	}()                                                                                                                   // 6
});                                                                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"user":{"route.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/routers/logged/admin/user/route.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Router.route('/admin/user', {                                                                                          // 1
	name: 'adminUser',                                                                                                    // 2
	template: 'adminUser',                                                                                                // 3
	title: 'Utilisateur',                                                                                                 // 4
	parent: 'adminBase',                                                                                                  // 5
	onBeforeAction: function () {                                                                                         // 6
		function onBeforeAction() {                                                                                          // 6
			var currentUserId = Meteor.userId();                                                                                // 7
			var currentUser = Meteor.users.findOne({ _id: currentUserId });                                                     // 8
			if (currentUser) {                                                                                                  // 9
				var currentUserRole = currentUser.profile.role;                                                                    // 10
                                                                                                                       //
				if (currentUserRole === 'admin') {                                                                                 // 12
					this.next();                                                                                                      // 13
				} else {                                                                                                           // 14
					Materialize.toast('Vous n\'avez pas l\'autorisation pour accéder à cette page !', 4000);                          // 16
					Router.go("login");                                                                                               // 17
				}                                                                                                                  // 18
			} else {                                                                                                            // 19
				Materialize.toast('Vous n\'avez pas l\'autorisation pour accéder à cette page !', 4000);                           // 21
				Router.go("login");                                                                                                // 22
			}                                                                                                                   // 23
		}                                                                                                                    // 24
                                                                                                                       //
		return onBeforeAction;                                                                                               // 6
	}()                                                                                                                   // 6
});                                                                                                                    // 1
                                                                                                                       //
Router.route('/admin/user/view', {                                                                                     // 27
	name: 'adminViewUser',                                                                                                // 28
	template: 'adminViewUser',                                                                                            // 29
	title: 'Consulter',                                                                                                   // 30
	parent: 'adminBase',                                                                                                  // 31
	onBeforeAction: function () {                                                                                         // 32
		function onBeforeAction() {                                                                                          // 32
			var currentUserId = Meteor.userId();                                                                                // 33
			var currentUser = Meteor.users.findOne({ _id: currentUserId });                                                     // 34
			if (currentUser) {                                                                                                  // 35
				var currentUserRole = currentUser.profile.role;                                                                    // 36
                                                                                                                       //
				if (currentUserRole === 'admin') {                                                                                 // 38
					this.next();                                                                                                      // 39
				} else {                                                                                                           // 40
					Materialize.toast('Vous n\'avez pas l\'autorisation pour accéder à cette page !', 4000);                          // 42
					Router.go("login");                                                                                               // 43
				}                                                                                                                  // 44
			} else {                                                                                                            // 45
				Materialize.toast('Vous n\'avez pas l\'autorisation pour accéder à cette page !', 4000);                           // 47
				Router.go("login");                                                                                                // 48
			}                                                                                                                   // 49
		}                                                                                                                    // 50
                                                                                                                       //
		return onBeforeAction;                                                                                               // 32
	}()                                                                                                                   // 32
});                                                                                                                    // 27
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"route.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/routers/logged/admin/route.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Router.route('/admin/', {                                                                                              // 1
	name: 'adminBase',                                                                                                    // 2
	template: 'adminBase',                                                                                                // 3
	title: 'admin',                                                                                                       // 4
	onBeforeAction: function () {                                                                                         // 5
		function onBeforeAction() {                                                                                          // 5
			Session.set('id_dat', "");                                                                                          // 6
			Session.set('id_esp', "");                                                                                          // 7
			Session.set('id_cont', "");                                                                                         // 8
			Session.set('id_fonc', "");                                                                                         // 9
			Session.set('id_enf', "");                                                                                          // 10
                                                                                                                       //
			var currentUserId = Meteor.userId();                                                                                // 12
			var currentUser = Meteor.users.findOne({ _id: currentUserId });                                                     // 13
			if (currentUser) {                                                                                                  // 14
				var currentUserRole = currentUser.profile.role;                                                                    // 15
                                                                                                                       //
				if (currentUserRole === 'admin') {                                                                                 // 17
					this.next();                                                                                                      // 18
				} else {                                                                                                           // 19
					Materialize.toast('Vous n\'avez pas l\'autorisation pour accéder à cette page !', 4000);                          // 21
					Router.go("login");                                                                                               // 22
				}                                                                                                                  // 23
			} else {                                                                                                            // 24
				Materialize.toast('Vous n\'avez pas l\'autorisation pour accéder à cette page !', 4000);                           // 26
				Router.go("login");                                                                                                // 27
			}                                                                                                                   // 28
		}                                                                                                                    // 29
                                                                                                                       //
		return onBeforeAction;                                                                                               // 5
	}()                                                                                                                   // 5
});                                                                                                                    // 1
                                                                                                                       //
Router.route('/admin/tdb', {                                                                                           // 32
	name: 'tdbAdmin',                                                                                                     // 33
	template: 'tdbAdmin',                                                                                                 // 34
	title: 'tdbAdmin',                                                                                                    // 35
	parent: 'adminBase',                                                                                                  // 36
	onBeforeAction: function () {                                                                                         // 37
		function onBeforeAction() {                                                                                          // 37
			var currentUserId = Meteor.userId();                                                                                // 38
			var currentUser = Meteor.users.findOne({ _id: currentUserId });                                                     // 39
			if (currentUser) {                                                                                                  // 40
				var currentUserRole = currentUser.profile.role;                                                                    // 41
				if (currentUserRole === 'admin') {                                                                                 // 42
					this.next();                                                                                                      // 43
				} else {                                                                                                           // 44
					Router.go('tdbAttente');                                                                                          // 46
				}                                                                                                                  // 47
			} else {                                                                                                            // 48
				//La redirection si on clique le lien par url et                                                                   // 50
				Materialize.toast('Vous n\'avez pas l\'autorisation pour accéder à cette page !', 4000);                           // 51
				Router.go("tdbAttente");                                                                                           // 52
			}                                                                                                                   // 53
		}                                                                                                                    // 54
                                                                                                                       //
		return onBeforeAction;                                                                                               // 37
	}()                                                                                                                   // 37
});                                                                                                                    // 32
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"attente":{"route.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/routers/logged/attente/route.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Router.route('/attente/', {                                                                                            // 1
	name: 'attenteBase',                                                                                                  // 2
	template: 'attenteBase',                                                                                              // 3
	title: 'attenteBase',                                                                                                 // 4
	onBeforeAction: function () {                                                                                         // 5
		function onBeforeAction() {                                                                                          // 5
			Session.set('id_dat', "");                                                                                          // 6
			Session.set('id_esp', "");                                                                                          // 7
			Session.set('id_cont', "");                                                                                         // 8
			Session.set('id_fonc', "");                                                                                         // 9
			Session.set('id_enf', "");                                                                                          // 10
			var currentUserId = Meteor.userId();                                                                                // 11
			var currentUser = Meteor.users.findOne({ _id: currentUserId });                                                     // 12
			if (currentUser) {                                                                                                  // 13
				var currentUserRole = currentUser.profile.role;                                                                    // 14
                                                                                                                       //
				if (currentUserRole === 'attente') {                                                                               // 16
					this.next();                                                                                                      // 17
				}                                                                                                                  // 18
			} else {                                                                                                            // 19
				Router.go("login");                                                                                                // 21
			}                                                                                                                   // 22
		}                                                                                                                    // 23
                                                                                                                       //
		return onBeforeAction;                                                                                               // 5
	}()                                                                                                                   // 5
});                                                                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"contributeur":{"route.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/routers/logged/contributeur/route.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Router.route('/contributeur/', {                                                                                       // 1
	name: 'contriBase',                                                                                                   // 2
	template: 'contriBase',                                                                                               // 3
	title: 'contributeur',                                                                                                // 4
	onBeforeAction: function () {                                                                                         // 5
		function onBeforeAction() {                                                                                          // 5
			Session.set('id_dat', "");                                                                                          // 6
			Session.set('id_esp', "");                                                                                          // 7
			Session.set('id_cont', "");                                                                                         // 8
			Session.set('id_fonc', "");                                                                                         // 9
			Session.set('id_enf', "");                                                                                          // 10
			var currentUserId = Meteor.userId();                                                                                // 11
			var currentUser = Meteor.users.findOne({ _id: currentUserId });                                                     // 12
			if (currentUser) {                                                                                                  // 13
				var currentUserRole = currentUser.profile.role;                                                                    // 14
                                                                                                                       //
				if (currentUserRole === 'contributeur') {                                                                          // 16
					this.next();                                                                                                      // 17
				} else {                                                                                                           // 18
					Materialize.toast('Vous n\'avez pas l\'autorisation pour accéder à cette page !', 4000);                          // 20
					Router.go("login");                                                                                               // 21
				}                                                                                                                  // 22
			} else {                                                                                                            // 23
				Materialize.toast('Vous n\'avez pas l\'autorisation pour accéder à cette page !', 4000);                           // 25
				Router.go("login");                                                                                                // 26
			}                                                                                                                   // 27
		}                                                                                                                    // 28
                                                                                                                       //
		return onBeforeAction;                                                                                               // 5
	}()                                                                                                                   // 5
});                                                                                                                    // 1
                                                                                                                       //
Router.route('contributeur/profile', {                                                                                 // 31
	name: 'profileContrib',                                                                                               // 32
	template: 'profileContrib',                                                                                           // 33
	title: 'contributeur',                                                                                                // 34
	parent: 'contriBase',                                                                                                 // 35
	onBeforeAction: function () {                                                                                         // 36
		function onBeforeAction() {                                                                                          // 36
			var currentUserId = Meteor.userId();                                                                                // 37
			var currentUser = Meteor.users.findOne({ _id: currentUserId });                                                     // 38
			if (currentUser) {                                                                                                  // 39
				var currentUserRole = currentUser.profile.role;                                                                    // 40
                                                                                                                       //
				if (currentUserRole === 'contributeur') {                                                                          // 42
					this.next();                                                                                                      // 43
				} else {                                                                                                           // 44
					Materialize.toast('Vous n\'avez pas l\'autorisation pour accéder à cette page !', 4000);                          // 46
					Router.go("login");                                                                                               // 47
				}                                                                                                                  // 48
			} else {                                                                                                            // 49
				Materialize.toast('Vous n\'avez pas l\'autorisation pour accéder à cette page !', 4000);                           // 51
				Router.go("login");                                                                                                // 52
			}                                                                                                                   // 53
		}                                                                                                                    // 54
                                                                                                                       //
		return onBeforeAction;                                                                                               // 36
	}()                                                                                                                   // 36
                                                                                                                       //
});                                                                                                                    // 31
                                                                                                                       //
Router.route('/contributeur/tdb', {                                                                                    // 58
	name: 'tdbContrib',                                                                                                   // 59
	template: 'tdbContrib',                                                                                               // 60
	title: 'contributeur',                                                                                                // 61
	parent: 'contriBase',                                                                                                 // 62
	onBeforeAction: function () {                                                                                         // 63
		function onBeforeAction() {                                                                                          // 63
			var currentUserId = Meteor.userId();                                                                                // 64
			var currentUser = Meteor.users.findOne({ _id: currentUserId });                                                     // 65
			if (currentUser) {                                                                                                  // 66
				var currentUserRole = currentUser.profile.role;                                                                    // 67
				if (currentUserRole === 'contributeur') {                                                                          // 68
					this.next();                                                                                                      // 69
				} else {                                                                                                           // 70
					Router.go("tdbAttente");                                                                                          // 72
				}                                                                                                                  // 73
			} else {                                                                                                            // 74
				Materialize.toast('Vous n\'avez pas l\'autorisation pour accéder à cette page !', 4000);                           // 76
				Router.go("tdbAttente");                                                                                           // 77
			}                                                                                                                   // 78
		}                                                                                                                    // 79
                                                                                                                       //
		return onBeforeAction;                                                                                               // 63
	}()                                                                                                                   // 63
});                                                                                                                    // 58
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"unlogged":{"route.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/routers/logged/unlogged/route.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Router.route('/tdb', {                                                                                                 // 1
	name: 'tdbAttente',                                                                                                   // 2
	template: 'tdbAttente',                                                                                               // 3
	title: 'attentetdb',                                                                                                  // 4
	onBeforeAction: function () {                                                                                         // 5
		function onBeforeAction() {                                                                                          // 5
			var currentUserId = Meteor.userId();                                                                                // 6
			var currentUser = Meteor.users.findOne({ _id: currentUserId });                                                     // 7
                                                                                                                       //
			if (currentUser) {                                                                                                  // 9
				var currentUserRole = currentUser.profile.role;                                                                    // 10
                                                                                                                       //
				if (currentUserRole === 'admin') {                                                                                 // 12
					Router.go('tdbAdmin');                                                                                            // 13
				} else if (currentUserRole === 'contributeur') {                                                                   // 14
					Router.go('tdbContrib');                                                                                          // 16
				}                                                                                                                  // 17
			} else {                                                                                                            // 18
				this.next();                                                                                                       // 20
			}                                                                                                                   // 21
		}                                                                                                                    // 22
                                                                                                                       //
		return onBeforeAction;                                                                                               // 5
	}()                                                                                                                   // 5
});                                                                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"crt":{"route.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/routers/crt/route.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Router.route('/dat/crt', {                                                                                             // 1
    name: 'crt',                                                                                                       // 2
    template: 'addCRT',                                                                                                // 3
    title: 'ajout cont',                                                                                               // 4
    onBeforeAction: function () {                                                                                      // 5
        function onBeforeAction() {                                                                                    // 5
            var currentUserId = Meteor.userId();                                                                       // 6
            var currentUser = Meteor.users.findOne({                                                                   // 7
                _id: currentUserId                                                                                     // 8
            });                                                                                                        // 7
            var idDat = Session.get('id_dat');                                                                         // 10
                                                                                                                       //
            if (currentUser) {                                                                                         // 12
                var currentUserRole = currentUser.profile.role;                                                        // 13
                var idUser = Dat.findOne({                                                                             // 14
                    _id: idDat                                                                                         // 15
                });                                                                                                    // 14
                                                                                                                       //
                if (idDat) {                                                                                           // 18
                    if (currentUserRole === 'admin') {                                                                 // 19
                        this.next();                                                                                   // 20
                    } else if (currentUserRole === "contributeur") {                                                   // 21
                        if (currentUser.dats.contructor === Array) {                                                   // 23
                            var i = dats.indexOf(idDat);                                                               // 24
                            if (i != -1) {                                                                             // 25
                                this.next();                                                                           // 26
                            } else {                                                                                   // 27
                                Router.go('home');                                                                     // 29
                            }                                                                                          // 30
                        }                                                                                              // 31
                    }                                                                                                  // 32
                }                                                                                                      // 33
            } else {                                                                                                   // 34
                Router.go('login');                                                                                    // 36
            }                                                                                                          // 37
        }                                                                                                              // 38
                                                                                                                       //
        return onBeforeAction;                                                                                         // 5
    }()                                                                                                                // 5
});                                                                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"dat":{"route.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/routers/dat/route.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Router.route('/ficheprojet', {                                                                                         // 1
    name: 'ficheProjet',                                                                                               // 2
    template: 'ficheProjet',                                                                                           // 3
    title: 'ficheProjet'                                                                                               // 4
});                                                                                                                    // 1
                                                                                                                       //
Router.route('/aide', {                                                                                                // 7
    name: 'aide',                                                                                                      // 8
    template: 'aide',                                                                                                  // 9
    title: 'aide'                                                                                                      // 10
});                                                                                                                    // 7
                                                                                                                       //
Router.route('/detailprojet', {                                                                                        // 13
    name: 'moreprojet',                                                                                                // 14
    template: 'moreprojet',                                                                                            // 15
    title: 'moreprojet',                                                                                               // 16
    onBeforeAction: function () {                                                                                      // 17
        function onBeforeAction() {                                                                                    // 17
            var iddat = Session.get('id_dat');                                                                         // 18
            if (iddat) {                                                                                               // 19
                this.next();                                                                                           // 20
            } else {                                                                                                   // 21
                Router.go('home');                                                                                     // 23
            }                                                                                                          // 24
        }                                                                                                              // 25
                                                                                                                       //
        return onBeforeAction;                                                                                         // 17
    }()                                                                                                                // 17
});                                                                                                                    // 13
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"enf":{"route.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/routers/enf/route.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Router.route('/dat/enf', {                                                                                             // 1
    name: 'enf',                                                                                                       // 2
    template: 'addENF',                                                                                                // 3
    title: 'ajout enf',                                                                                                // 4
    onBeforeAction: function () {                                                                                      // 5
        function onBeforeAction() {                                                                                    // 5
            var currentUserId = Meteor.userId();                                                                       // 6
            var currentUser = Meteor.users.findOne({                                                                   // 7
                _id: currentUserId                                                                                     // 8
            });                                                                                                        // 7
            var idDat = Session.get('id_dat');                                                                         // 10
                                                                                                                       //
            if (currentUser) {                                                                                         // 12
                var currentUserRole = currentUser.profile.role;                                                        // 13
                var idUser = Dat.findOne({                                                                             // 14
                    _id: idDat                                                                                         // 15
                });                                                                                                    // 14
                                                                                                                       //
                if (idDat) {                                                                                           // 18
                    if (currentUserRole === 'admin') {                                                                 // 19
                        this.next();                                                                                   // 20
                    } else if (currentUserRole === "contributeur") {                                                   // 21
                        if (currentUser.dats.contructor === Array) {                                                   // 23
                            var i = dats.indexOf(idDat);                                                               // 24
                            if (i != -1) {                                                                             // 25
                                this.next();                                                                           // 26
                            } else {                                                                                   // 27
                                Router.go('home');                                                                     // 29
                            }                                                                                          // 30
                        }                                                                                              // 31
                    }                                                                                                  // 32
                }                                                                                                      // 33
            } else {                                                                                                   // 34
                Router.go('login');                                                                                    // 36
            }                                                                                                          // 37
        }                                                                                                              // 38
                                                                                                                       //
        return onBeforeAction;                                                                                         // 5
    }()                                                                                                                // 5
});                                                                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"esp":{"route.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/routers/esp/route.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Router.route('/dat/esp', {                                                                                             // 1
    name: 'esp',                                                                                                       // 2
    template: 'addESP',                                                                                                // 3
    title: 'ajout esp',                                                                                                // 4
    onBeforeAction: function () {                                                                                      // 5
        function onBeforeAction() {                                                                                    // 5
            var currentUserId = Meteor.userId();                                                                       // 6
            var currentUser = Meteor.users.findOne({                                                                   // 7
                _id: currentUserId                                                                                     // 8
            });                                                                                                        // 7
            var idDat = Session.get('id_dat');                                                                         // 10
                                                                                                                       //
            if (currentUser) {                                                                                         // 12
                var currentUserRole = currentUser.profile.role;                                                        // 13
                var idUser = Dat.findOne({                                                                             // 14
                    _id: idDat                                                                                         // 15
                });                                                                                                    // 14
                                                                                                                       //
                if (idDat) {                                                                                           // 18
                    if (currentUserRole === 'admin') {                                                                 // 19
                        this.next();                                                                                   // 20
                    } else if (currentUserRole === "contributeur") {                                                   // 21
                        if (currentUser.dats.contructor === Array) {                                                   // 23
                            var i = dats.indexOf(idDat);                                                               // 24
                            if (i != -1) {                                                                             // 25
                                this.next();                                                                           // 26
                            } else {                                                                                   // 27
                                Router.go('home');                                                                     // 29
                            }                                                                                          // 30
                        }                                                                                              // 31
                    }                                                                                                  // 32
                }                                                                                                      // 33
            } else {                                                                                                   // 34
                Router.go('login');                                                                                    // 36
            }                                                                                                          // 37
        }                                                                                                              // 38
                                                                                                                       //
        return onBeforeAction;                                                                                         // 5
    }()                                                                                                                // 5
});                                                                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"fsd":{"route.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/routers/fsd/route.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Router.route('/dat/fsd', {                                                                                             // 1
    name: 'fonc',                                                                                                      // 2
    template: 'addFSD',                                                                                                // 3
    title: 'ajout fonc',                                                                                               // 4
    onBeforeAction: function () {                                                                                      // 5
        function onBeforeAction() {                                                                                    // 5
            var currentUserId = Meteor.userId();                                                                       // 6
            var currentUser = Meteor.users.findOne({                                                                   // 7
                _id: currentUserId                                                                                     // 8
            });                                                                                                        // 7
            var idDat = Session.get('id_dat');                                                                         // 10
                                                                                                                       //
            if (currentUser) {                                                                                         // 12
                var currentUserRole = currentUser.profile.role;                                                        // 13
                var idUser = Dat.findOne({                                                                             // 14
                    _id: idDat                                                                                         // 15
                });                                                                                                    // 14
                                                                                                                       //
                if (idDat) {                                                                                           // 18
                    if (currentUserRole === 'admin') {                                                                 // 19
                        this.next();                                                                                   // 20
                    } else if (currentUserRole === "contributeur") {                                                   // 21
                        if (currentUser.dats.contructor === Array) {                                                   // 23
                            var i = dats.indexOf(idDat);                                                               // 24
                            if (i != -1) {                                                                             // 25
                                this.next();                                                                           // 26
                            } else {                                                                                   // 27
                                Router.go('home');                                                                     // 29
                            }                                                                                          // 30
                        }                                                                                              // 31
                    }                                                                                                  // 32
                }                                                                                                      // 33
            } else {                                                                                                   // 34
                Router.go('login');                                                                                    // 36
            }                                                                                                          // 37
        }                                                                                                              // 38
                                                                                                                       //
        return onBeforeAction;                                                                                         // 5
    }()                                                                                                                // 5
});                                                                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"home":{"route.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/routers/home/route.js                                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Router.route('/', {                                                                                                    // 1
	name: 'home',                                                                                                         // 2
	template: 'homeBase',                                                                                                 // 3
	title: 'Accueil',                                                                                                     // 4
	onBeforeAction: function () {                                                                                         // 5
		function onBeforeAction() {                                                                                          // 5
			Session.set('id_dat', "");                                                                                          // 6
			Session.set('id_esp', "");                                                                                          // 7
			Session.set('id_cont', "");                                                                                         // 8
			Session.set('id_fonc', "");                                                                                         // 9
			Session.set('id_enf', "");                                                                                          // 10
                                                                                                                       //
			var currentUserId = Meteor.userId();                                                                                // 12
			var currentUser = Meteor.users.findOne({ _id: currentUserId });                                                     // 13
                                                                                                                       //
			if (currentUser) {                                                                                                  // 15
				var currentUserRole = currentUser.profile.role;                                                                    // 16
                                                                                                                       //
				if (currentUserRole === 'admin') {                                                                                 // 18
					Router.go('adminBase');                                                                                           // 19
				} else if (currentUserRole === 'contributeur') {                                                                   // 20
					Router.go('contriBase');                                                                                          // 22
				} else if (currentUserRole === 'attente') {                                                                        // 23
					Router.go('attenteBase');                                                                                         // 25
				}                                                                                                                  // 26
			} else {                                                                                                            // 27
				this.next();                                                                                                       // 29
			}                                                                                                                   // 30
		}                                                                                                                    // 31
                                                                                                                       //
		return onBeforeAction;                                                                                               // 5
	}()                                                                                                                   // 5
});                                                                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"login":{"route.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/routers/login/route.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Router.route('/login', {                                                                                               // 1
	name: 'login',                                                                                                        // 2
	template: 'loginBase',                                                                                                // 3
	title: 'Connexion',                                                                                                   // 4
	parent: 'home',                                                                                                       // 5
	onBeforeAction: function () {                                                                                         // 6
		function onBeforeAction() {                                                                                          // 6
			var currentUserId = Meteor.userId();                                                                                // 7
			var currentUser = Meteor.users.findOne({ _id: currentUserId });                                                     // 8
			if (currentUser) {                                                                                                  // 9
				Materialize.toast('Vous êtes déjà connecté !', 4000);                                                              // 10
				var currentUserRole = currentUser.profile.role;                                                                    // 11
				switch (currentUserRole) {                                                                                         // 12
					case 'admin':                                                                                                     // 13
						Router.go("adminBase");                                                                                          // 14
						break;                                                                                                           // 15
					case 'contributeur':                                                                                              // 16
						Router.go('contriBase');                                                                                         // 17
						break;                                                                                                           // 18
					case 'attente':                                                                                                   // 19
						Router.go('attenteBase');                                                                                        // 20
						Materialize.toast("Veuillez vous reconnecter ultérieurement... Votre compte n\'a pas été validé par l'admin", 4000);
				}                                                                                                                  // 12
			} else {                                                                                                            // 23
				this.next();                                                                                                       // 25
			}                                                                                                                   // 26
		}                                                                                                                    // 27
                                                                                                                       //
		return onBeforeAction;                                                                                               // 6
	}()                                                                                                                   // 6
});                                                                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"register":{"route.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/routers/register/route.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Router.route('/register', {                                                                                            // 1
	name: 'register',                                                                                                     // 2
	template: 'registerBase',                                                                                             // 3
	title: 'Enregistrement'                                                                                               // 4
});                                                                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"route.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/routers/route.js                                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Router.configure({                                                                                                     // 1
   layoutTemplate: 'defaultBase'                                                                                       // 2
});                                                                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"collections":{"crt":{"RedVol.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/crt/RedVol.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
RedVol = new Meteor.Collection('redvol');                                                                              // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"VolDonnee.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/crt/VolDonnee.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
VolDonnee = new Meteor.Collection('voldonnee');                                                                        // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"crt.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/crt/crt.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Crt = new Mongo.Collection('crt');                                                                                     // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dependance.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/crt/dependance.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Dependance = new Meteor.Collection('dependance');                                                                      // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"hebergement.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/crt/hebergement.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Hebergement = new Meteor.Collection('hebergement');                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"posttravail.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/crt/posttravail.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
PostTravail = new Meteor.Collection('posttravail');                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"reglementaire.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/crt/reglementaire.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Reglementaire = new Meteor.Collection('reglementaire');                                                                // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"securite.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/crt/securite.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Securite = new Meteor.Collection('securite');                                                                          // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"typepdt.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/crt/typepdt.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
TypePostdTravail = new Meteor.Collection('typepostedetravail');                                                        // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"volFichier.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/crt/volFichier.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
VolFichier = new Meteor.Collection('volfichier');                                                                      // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"volumetrie.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/crt/volumetrie.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Volumetrie = new Meteor.Collection('volumetrie');                                                                      // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"enf":{"critDispo.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/enf/critDispo.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
CritDispo = new Meteor.Collection('CritDispo');                                                                        // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"critDispoAppMetier.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/enf/critDispoAppMetier.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
CritDispoAppMetier = new Meteor.Collection('critDispoAppMetier');                                                      // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"critDispoPeriode.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/enf/critDispoPeriode.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
CritDispoPeriode = new Meteor.Collection('critDispoPeriode');                                                          // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"critExploi.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/enf/critExploi.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
CritExploi = new Meteor.Collection('critExploi');                                                                      // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"critExploiBatch.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/enf/critExploiBatch.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
BatchApplicatif = new Meteor.Collection('batchApplicatif');                                                            // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"critExploiImpact.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/enf/critExploiImpact.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
CritExploiImpact = new Meteor.Collection('critExploiImpact');                                                          // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"critPerformance.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/enf/critPerformance.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
CritPerformance = new Meteor.Collection('critPerformance');                                                            // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"critSecuExigence.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/enf/critSecuExigence.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
CritSecuExigence = new Meteor.Collection('critSecuExigence');                                                          // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"critSecurite.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/enf/critSecurite.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
CritSecurite = new Meteor.Collection('critSecurite');                                                                  // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"critTypeAppMetier.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/enf/critTypeAppMetier.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
CritTypeAppMetier = new Meteor.Collection('critTypeAppMetier');                                                        // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"critTypePerfPeriode.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/enf/critTypePerfPeriode.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
CritTypePerfPeriode = new Meteor.Collection('critTypePerfPeriode');                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"critTypeTemps.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/enf/critTypeTemps.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
CritTypeTempsReponse = new Meteor.Collection('critTypeTempsReponse');                                                  // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"enf.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/enf/enf.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Enf = new Mongo.Collection('enf');                                                                                     // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"typeCritImpact.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/enf/typeCritImpact.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
TypecritImpact = new Meteor.Collection('typecritImpact');                                                              // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"typeSecuExigence.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/enf/typeSecuExigence.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
TypecritExigence = new Meteor.Collection('typecritExigence');                                                          // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"esp":{"Enjeux.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/esp/Enjeux.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Enjeux = new Meteor.Collection('enjeux');                                                                              // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"Objectifs.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/esp/Objectifs.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Objectifs = new Meteor.Collection('objectifs');                                                                        // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"TypeActeur.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/esp/TypeActeur.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
TypeActeur = new Meteor.Collection('typeActeur');                                                                      // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"acteurProjet.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/esp/acteurProjet.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
ActeurProjet = new Meteor.Collection('acteurProjet');                                                                  // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"acteurUsager.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/esp/acteurUsager.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
ActeurUsager = new Meteor.Collection('acteurUsager');                                                                  // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"contexte.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/esp/contexte.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Contexte = new Meteor.Collection('contexte');                                                                          // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"esp.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/esp/esp.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Esp = new Mongo.Collection('esp');                                                                                     // 1
                                                                                                                       //
/* _id :                                                                                                               // 3
    Array : Objectifs                                                                                                  //
    Array : Enjeux                                                                                                     //
    Array : Acteur projet                                                                                              //
    Array : Acteur usager                                                                                              //
*/                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"planning.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/esp/planning.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Planning = new Meteor.Collection('planning');                                                                          // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"fsd":{"donMetier.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/fsd/donMetier.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
DonMetier = new Meteor.Collection('donmetier');                                                                        // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"foncMetier.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/fsd/foncMetier.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
FoncMetier = new Meteor.Collection('foncmetier');                                                                      // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"fsd.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/fsd/fsd.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Fsd = new Mongo.Collection('fsd');                                                                                     // 1
                                                                                                                       //
/* _id :                                                                                                               // 3
    Array : Fonctionnalité Metier                                                                                      //
    Array : Donnees metier                                                                                             //
    Array : Pieces jointes metier                                                                                      //
    Array : Referentiels donnees                                                                                       //
*/                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"pjMetier.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/fsd/pjMetier.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
PjMetier = new Meteor.Collection('pjmetier');                                                                          // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"refDonnees.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/fsd/refDonnees.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
RefDonnees = new Meteor.Collection('refdonnees');                                                                      // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"serviceConnexe.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/fsd/serviceConnexe.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
ServiceConnexe = new Meteor.Collection('serviceConnexe');                                                              // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"user":{"role.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/user/role.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Roles = new Meteor.Collection("role");                                                                                 // 1
                                                                                                                       //
/*                                                                                                                     // 3
	Roles :                                                                                                               //
		- _id                                                                                                                //
		- name                                                                                                               //
		- displayName                                                                                                        //
*/                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"dat.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/dat.js                                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Dat = new Meteor.Collection('dat');                                                                                    // 1
                                                                                                                       //
/* Name : nom du pro                                                                                                   // 3
   id : elements structurants                                                                                          //
   id : fonctionnalités                                                                                                //
   id : contraintes                                                                                                    //
   id : exigences non fonctionnelles                                                                                   //
*/                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"methods":{"dat":{"enf":{"critDispo":{"appmetier":{"typeappmetier":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/enf/critDispo/appmetier/typeappmetier/methods.js                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//type app metier                                                                                                      // 1
Meteor.methods({                                                                                                       // 2
  'addTypeAppmetier': function () {                                                                                    // 3
    function addTypeAppmetier(typecE) {                                                                                // 3
      console.log("The method 'addTypeAppmetier' has been called !");                                                  // 4
      console.log("Type acteur : " + typecE);                                                                          // 5
                                                                                                                       //
      return CritTypeAppMetier.insert({ name: typecE });                                                               // 7
    }                                                                                                                  // 8
                                                                                                                       //
    return addTypeAppmetier;                                                                                           // 3
  }(),                                                                                                                 // 3
  'deleteTypeAppmetier': function () {                                                                                 // 9
    function deleteTypeAppmetier(typeCEId) {                                                                           // 9
      console.log("The method 'deleteTypeAppmetier' has been called !");                                               // 10
      console.log("Id Type Acteur : " + typeCEId);                                                                     // 11
                                                                                                                       //
      return CritTypeAppMetier.remove({ _id: typeCEId });                                                              // 13
    }                                                                                                                  // 14
                                                                                                                       //
    return deleteTypeAppmetier;                                                                                        // 9
  }()                                                                                                                  // 9
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/enf/critDispo/appmetier/methods.js                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//APP METIER                                                                                                           // 1
Meteor.methods({                                                                                                       // 2
    'addcritDispoAppMetier': function () {                                                                             // 3
        function addcritDispoAppMetier(idtypeAppmetier) {                                                              // 3
            console.log("The method 'addcritDispoPeriode' has been called !");                                         // 4
            console.log("\tID type Appmetier : " + idtypeAppmetier);                                                   // 5
                                                                                                                       //
            return CritDispoAppMetier.insert({ typeappmetier: idtypeAppmetier,                                         // 7
                standard: "",                                                                                          // 8
                haute: "",                                                                                             // 9
                createAt: new Date()                                                                                   // 10
            });                                                                                                        // 7
        }                                                                                                              // 12
                                                                                                                       //
        return addcritDispoAppMetier;                                                                                  // 3
    }(),                                                                                                               // 3
    'updatecritDispoAppMetier': function () {                                                                          // 13
        function updatecritDispoAppMetier(idDispoAppmetier, standard, haute) {                                         // 13
            console.log("The method 'updatecritDispoPeriode' has been called !");                                      // 14
            console.log("\tID Dispo Periode : " + idDispoAppmetier);                                                   // 15
            console.log("\tstandard : " + standard);                                                                   // 16
            console.log("\thaute : " + haute);                                                                         // 17
                                                                                                                       //
            return CritDispoAppMetier.update({ _id: idDispoAppmetier }, { $set: { standard: standard, haute: haute } });
        }                                                                                                              // 21
                                                                                                                       //
        return updatecritDispoAppMetier;                                                                               // 13
    }(),                                                                                                               // 13
    'deletecritDispoAppMetier': function () {                                                                          // 22
        function deletecritDispoAppMetier(idDispoAppmetier) {                                                          // 22
            console.log("The method 'deletecritDispoPeriode' has been called !");                                      // 23
            console.log("\tID Dispo Periode : " + idDispoAppmetier);                                                   // 24
                                                                                                                       //
            return CritDispoAppMetier.remove({ _id: idDispoAppmetier });                                               // 26
        }                                                                                                              // 27
                                                                                                                       //
        return deletecritDispoAppMetier;                                                                               // 22
    }()                                                                                                                // 22
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"periode":{"typeperiode":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/enf/critDispo/periode/typeperiode/methods.js                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//type periode                                                                                                         // 1
Meteor.methods({                                                                                                       // 2
  'addTypePeriode': function () {                                                                                      // 3
    function addTypePeriode(typecE) {                                                                                  // 3
      console.log("The method 'addTypePeriode' has been called !");                                                    // 4
      console.log("Type acteur : " + typecE);                                                                          // 5
                                                                                                                       //
      return CritTypePerfPeriode.insert({ name: typecE });                                                             // 7
    }                                                                                                                  // 8
                                                                                                                       //
    return addTypePeriode;                                                                                             // 3
  }(),                                                                                                                 // 3
  'deleteTypePeriode': function () {                                                                                   // 9
    function deleteTypePeriode(typeCEId) {                                                                             // 9
      console.log("The method 'deleteTypeA' has been called !");                                                       // 10
      console.log("Id Type Acteur : " + typeCEId);                                                                     // 11
                                                                                                                       //
      return CritTypePerfPeriode.remove({ _id: typeCEId });                                                            // 13
    }                                                                                                                  // 14
                                                                                                                       //
    return deleteTypePeriode;                                                                                          // 9
  }()                                                                                                                  // 9
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/enf/critDispo/periode/methods.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//PERIODE                                                                                                              // 1
Meteor.methods({                                                                                                       // 2
    'addcritDispoPeriode': function () {                                                                               // 3
        function addcritDispoPeriode(idtypePeriode) {                                                                  // 3
            console.log("The method 'addcritDispoPeriode' has been called !");                                         // 4
            console.log("\tID type Exigence : " + idtypePeriode);                                                      // 5
                                                                                                                       //
            return CritDispoPeriode.insert({ typePeriode: idtypePeriode,                                               // 7
                debut: "",                                                                                             // 8
                fin: "",                                                                                               // 9
                nbu: "",                                                                                               // 10
                cht: "",                                                                                               // 11
                createAt: new Date()                                                                                   // 12
            });                                                                                                        // 7
        }                                                                                                              // 14
                                                                                                                       //
        return addcritDispoPeriode;                                                                                    // 3
    }(),                                                                                                               // 3
    'updatecritDispoPeriode': function () {                                                                            // 15
        function updatecritDispoPeriode(idDispoPeriode, debut, fin, nbu, cht) {                                        // 15
            console.log("The method 'updatecritDispoPeriode' has been called !");                                      // 16
            console.log("\tID Dispo Periode : " + idDispoPeriode);                                                     // 17
            console.log("\tdebut : " + debut);                                                                         // 18
            console.log("\tfin : " + fin);                                                                             // 19
            console.log("\tnbu : " + nbu);                                                                             // 20
            console.log("\t cht : " + cht);                                                                            // 21
                                                                                                                       //
            return CritDispoPeriode.update({ _id: idDispoPeriode }, { $set: { debut: debut, fin: fin, nbu: nbu, cht: cht } });
        }                                                                                                              // 25
                                                                                                                       //
        return updatecritDispoPeriode;                                                                                 // 15
    }(),                                                                                                               // 15
    'deletecritDispoPeriode': function () {                                                                            // 26
        function deletecritDispoPeriode(idDispoPeriode) {                                                              // 26
            console.log("The method 'deletecritDispoPeriode' has been called !");                                      // 27
            console.log("\tID Dispo Periode : " + idDispoPeriode);                                                     // 28
                                                                                                                       //
            return CritDispoPeriode.remove({ _id: idDispoPeriode });                                                   // 30
        }                                                                                                              // 31
                                                                                                                       //
        return deletecritDispoPeriode;                                                                                 // 26
    }()                                                                                                                // 26
                                                                                                                       //
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/enf/critDispo/methods.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//critere de dispo                                                                                                     // 1
Meteor.methods({                                                                                                       // 2
    'addcritDispoEmpty': function () {                                                                                 // 3
        function addcritDispoEmpty() {                                                                                 // 3
            console.log("The method 'addcritPerfPeriodeEmpty' has been called !");                                     // 4
            //TABLEAU PERIODE                                                                                          // 5
            var tperiode = [];                                                                                         // 6
            CritTypePerfPeriode.find().forEach(function (typep) {                                                      // 7
                tperiode.push(typep._id);                                                                              // 8
            });                                                                                                        // 9
            var periode = [];                                                                                          // 10
            for (var i = 0; i < tperiode.length; i++) {                                                                // 11
                var p = Meteor.call('addcritDispoPeriode', tperiode[i]);                                               // 12
                periode.push(p);                                                                                       // 13
            }                                                                                                          // 14
            //TABLEAU APP METIER                                                                                       // 15
            var tappmetier = [];                                                                                       // 16
            CritTypeAppMetier.find().forEach(function (typeapp) {                                                      // 17
                tappmetier.push(typeapp._id);                                                                          // 18
            });                                                                                                        // 19
            var appmetier = [];                                                                                        // 20
            for (var i = 0; i < tappmetier.length; i++) {                                                              // 21
                var ap = Meteor.call('addcritDispoAppMetier', tappmetier[i]);                                          // 22
                appmetier.push(ap);                                                                                    // 23
            }                                                                                                          // 24
            return CritDispo.insert({ periode: periode, description: "", appmetier: appmetier });                      // 25
        }                                                                                                              // 26
                                                                                                                       //
        return addcritDispoEmpty;                                                                                      // 3
    }(),                                                                                                               // 3
    'updatecritDispo': function () {                                                                                   // 27
        function updatecritDispo(idcritDispo, description) {                                                           // 27
            console.log("The method 'updatecritDispo' has been called !");                                             // 28
            console.log("\tid critere dispo : " + idcritDispo);                                                        // 29
            console.log("\tdescription : " + description);                                                             // 30
                                                                                                                       //
            return CritDispo.update({ _id: idcritDispo }, { $set: { description: description } });                     // 32
        }                                                                                                              // 33
                                                                                                                       //
        return updatecritDispo;                                                                                        // 27
    }(),                                                                                                               // 27
    'deleteSecuritDispo': function () {                                                                                // 34
        function deleteSecuritDispo(idcritDispo) {                                                                     // 34
            console.log("The method 'deleteSecuritDispo' has been called !");                                          // 35
            console.log("\tid critere securite : " + idcritDispo);                                                     // 36
                                                                                                                       //
            var critdispo = CritDispo.findOne({ _id: idcritDispo });                                                   // 38
            //PERIODES                                                                                                 // 39
            var periodes = critdispo.periode;                                                                          // 40
            var appmetier = critdispo.appmetier;                                                                       // 41
            for (var i = 0; i < periodes.length; i++) {                                                                // 42
                Meteor.call('deletecritDispoPeriode', periodes[i]);                                                    // 43
            }                                                                                                          // 44
            //APPMETIER                                                                                                // 45
            for (i = 0; i < appmetier.length; i++) {                                                                   // 46
                Meteor.call('deletecritDispoAppMetier', appmetier[i]);                                                 // 47
            }                                                                                                          // 48
            return CritDispo.remove({ _id: idcritDispo });                                                             // 49
        }                                                                                                              // 50
                                                                                                                       //
        return deleteSecuritDispo;                                                                                     // 34
    }()                                                                                                                // 34
                                                                                                                       //
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"critExploit":{"impact":{"typeImpact":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/enf/critExploit/impact/typeImpact/methods.js                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//type Impact                                                                                                          // 1
Meteor.methods({                                                                                                       // 2
  'addTypecritImpact': function () {                                                                                   // 3
    function addTypecritImpact(typecI) {                                                                               // 3
      console.log("The method 'addTypecritImpact' has been called !");                                                 // 4
      console.log("Type acteur : " + typecI);                                                                          // 5
                                                                                                                       //
      return TypecritImpact.insert({ name: typecI });                                                                  // 7
    }                                                                                                                  // 8
                                                                                                                       //
    return addTypecritImpact;                                                                                          // 3
  }(),                                                                                                                 // 3
  'deleteTypecritImpact': function () {                                                                                // 9
    function deleteTypecritImpact(typeCEId) {                                                                          // 9
      console.log("The method 'deleteTypecritImpact' has been called !");                                              // 10
      console.log("Id Type Acteur : " + typeCEId);                                                                     // 11
                                                                                                                       //
      return TypecritImpact.remove({ _id: typeCEId });                                                                 // 13
    }                                                                                                                  // 14
                                                                                                                       //
    return deleteTypecritImpact;                                                                                       // 9
  }()                                                                                                                  // 9
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/enf/critExploit/impact/methods.js                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Impact                                                                                                               // 1
Meteor.methods({                                                                                                       // 2
    'addcritExploiImpact': function () {                                                                               // 3
        function addcritExploiImpact(idTypeImpact) {                                                                   // 3
            console.log("The method 'addcritSecuExigence' has been called !");                                         // 4
            console.log("\tID type Impact : " + idTypeImpact);                                                         // 5
                                                                                                                       //
            return tdr = CritExploiImpact.insert({ typeImpact: idTypeImpact, description: "", createAt: new Date() });
        }                                                                                                              // 9
                                                                                                                       //
        return addcritExploiImpact;                                                                                    // 3
    }(),                                                                                                               // 3
    'updatecritExploiImpact': function () {                                                                            // 10
        function updatecritExploiImpact(idTypeImpact, description) {                                                   // 10
            console.log("The method 'updatecritExploiImpact' has been called !");                                      // 11
            console.log("\tID Exploi Impact : " + idTypeImpact);                                                       // 12
            console.log("\tdescription : " + description);                                                             // 13
                                                                                                                       //
            return CritExploiImpact.update({ _id: idTypeImpact }, { $set: { description: description } });             // 15
        }                                                                                                              // 16
                                                                                                                       //
        return updatecritExploiImpact;                                                                                 // 10
    }(),                                                                                                               // 10
    'deletecritExploiImpact': function () {                                                                            // 17
        function deletecritExploiImpact(idTypeImpact) {                                                                // 17
            console.log("The method 'deletecritExploiImpact' has been called !");                                      // 18
            console.log("\tID Exploi Impact : " + idTypeImpact);                                                       // 19
                                                                                                                       //
            return CritExploiImpact.remove({ _id: idTypeImpact });                                                     // 21
        }                                                                                                              // 22
                                                                                                                       //
        return deletecritExploiImpact;                                                                                 // 17
    }()                                                                                                                // 17
                                                                                                                       //
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"batch":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/enf/critExploit/batch/methods.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//BATCH                                                                                                                // 1
Meteor.methods({                                                                                                       // 2
    'addBatchAppliEmpty': function () {                                                                                // 3
        function addBatchAppliEmpty() {                                                                                // 3
            console.log("The method 'addBatchAppliEmpty' has been called!");                                           // 4
            return BatchApplicatif.insert({ batch: "", plage: "", frequence: "", impactMetier: "", impactCharge: "", createAt: new Date() });
        }                                                                                                              // 6
                                                                                                                       //
        return addBatchAppliEmpty;                                                                                     // 3
    }(),                                                                                                               // 3
    'updateBatchAppli': function () {                                                                                  // 7
        function updateBatchAppli(idBatchAppl, batch, plage, frequence, impactMetier, impactCharge) {                  // 7
            console.log("The method 'updateBatchAppli' has been called!");                                             // 8
            console.log("\tBatch ID : " + idBatchAppl);                                                                // 9
            console.log("\tbatch :" + batch);                                                                          // 10
            console.log("\tplage :" + plage);                                                                          // 11
            console.log("\tfrequence :" + frequence);                                                                  // 12
            console.log("\timpactMetier :" + impactMetier);                                                            // 13
            console.log("\timpactCharge :" + impactCharge);                                                            // 14
                                                                                                                       //
            return BatchApplicatif.update({ _id: idBatchAppl }, { $set: { batch: batch, plage: plage, frequence: frequence, impactMetier: impactMetier, impactCharge: impactCharge } });
        }                                                                                                              // 17
                                                                                                                       //
        return updateBatchAppli;                                                                                       // 7
    }(),                                                                                                               // 7
    'deleteBatchAppli': function () {                                                                                  // 18
        function deleteBatchAppli(idBatchAppl) {                                                                       // 18
            console.log("The method 'deleteBatchAppli' has been called!");                                             // 19
            console.log("\tBatch ID : " + idBatchAppl);                                                                // 20
                                                                                                                       //
            Enf.find().forEach(function (enf) {                                                                        // 22
                Meteor.call('deleteDependanceToCrt', enf._id, idBatchAppl);                                            // 23
            });                                                                                                        // 24
            return BatchApplicatif.remove(idBatchAppl);                                                                // 25
        }                                                                                                              // 26
                                                                                                                       //
        return deleteBatchAppli;                                                                                       // 18
    }(),                                                                                                               // 18
    'deleteBatchAppliById': function () {                                                                              // 27
        function deleteBatchAppliById(idBatchAppl) {                                                                   // 27
            console.log("The method 'deleteBatchAppliById' has been called!");                                         // 28
            console.log("\tBatch ID : " + idBatchAppl);                                                                // 29
                                                                                                                       //
            return BatchApplicatif.remove(idBatchAppl);                                                                // 31
        }                                                                                                              // 32
                                                                                                                       //
        return deleteBatchAppliById;                                                                                   // 27
    }()                                                                                                                // 27
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/enf/critExploit/methods.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Critere Exploi                                                                                                       // 1
                                                                                                                       //
Meteor.methods({                                                                                                       // 3
    'addCritExploiEmpty': function () {                                                                                // 4
        function addCritExploiEmpty() {                                                                                // 4
            console.log("The method 'addCritExploiEmpty' has been called !");                                          // 5
            var typeimpact = [];                                                                                       // 6
            TypecritImpact.find().forEach(function (typeCS) {                                                          // 7
                typeimpact.push(typeCS._id);                                                                           // 8
            });                                                                                                        // 9
                                                                                                                       //
            var impact = [];                                                                                           // 11
            for (var i = 0; i < typeimpact.length; i++) {                                                              // 12
                var cs = Meteor.call('addcritExploiImpact', typeimpact[i]);                                            // 13
                impact.push(cs);                                                                                       // 14
            }                                                                                                          // 15
            return CritExploi.insert({ impact: impact, batchAppl: [], createAt: new Date() });                         // 16
        }                                                                                                              // 18
                                                                                                                       //
        return addCritExploiEmpty;                                                                                     // 4
    }(),                                                                                                               // 4
    'updateCritExploi': function () {                                                                                  // 19
        function updateCritExploi(idCExploi, etude) {                                                                  // 19
            console.log("The method 'updateCritExploi' has been called !");                                            // 20
            console.log("\tid critere securite : " + idCExploi);                                                       // 21
            console.log("\tEtude : " + etude);                                                                         // 22
                                                                                                                       //
            return CritExploi.update({ _id: idCExploi }, { $set: { etude: etude } });                                  // 24
        }                                                                                                              // 25
                                                                                                                       //
        return updateCritExploi;                                                                                       // 19
    }(),                                                                                                               // 19
                                                                                                                       //
    'addBatchToCritExploi': function () {                                                                              // 27
        function addBatchToCritExploi(idCExploi, idBatchAppl) {                                                        // 27
            console.log("The method 'addBatchToCritExploi' has been called !");                                        // 28
            console.log("Id crit Exploi : " + idCExploi);                                                              // 29
            console.log("id Batch Appl : " + idBatchAppl);                                                             // 30
                                                                                                                       //
            var critImpact = CritExploi.findOne({ _id: idCExploi });                                                   // 32
            var batchAppli = critImpact.batchAppl;                                                                     // 33
            var i = batchAppli.indexOf(idBatchAppl);                                                                   // 34
                                                                                                                       //
            if (i == -1) {                                                                                             // 36
                batchAppli.push(idBatchAppl);                                                                          // 37
                CritExploi.update({ _id: idCExploi }, { $set: { batchAppl: batchAppli } });                            // 38
            }                                                                                                          // 39
        }                                                                                                              // 40
                                                                                                                       //
        return addBatchToCritExploi;                                                                                   // 27
    }(),                                                                                                               // 27
    'updateBatchToCritExploi': function () {                                                                           // 41
        function updateBatchToCritExploi(idCExploi, idBatchAppl) {                                                     // 41
            console.log("The method 'updateBatchToCritExploi' has been called !");                                     // 42
            console.log("Id crit Exploi : " + idCExploi);                                                              // 43
            console.log("id Batch Appl : " + idBatchAppl);                                                             // 44
                                                                                                                       //
            var critImpact = CritExploi.findOne({ _id: idCExploi });                                                   // 46
            var batchAppli = critImpact.batchAppl;                                                                     // 47
            var i = batchAppli.indexOf(idBatchAppl);                                                                   // 48
                                                                                                                       //
            if (i != -1) {                                                                                             // 50
                Meteor.call('deleteBatchAppliById', idBatchAppl);                                                      // 51
                batchAppli.splice(i, 1);                                                                               // 52
                CritExploi.update({ _id: idCExploi }, { $set: { batchAppl: batchAppli } });                            // 53
            }                                                                                                          // 54
        }                                                                                                              // 55
                                                                                                                       //
        return updateBatchToCritExploi;                                                                                // 41
    }(),                                                                                                               // 41
                                                                                                                       //
    'deleteCritExploi': function () {                                                                                  // 57
        function deleteCritExploi(idCExploi) {                                                                         // 57
            console.log("The method 'deleteCritExploi' has been called !");                                            // 58
            console.log("\tid critere securite : " + idCExploi);                                                       // 59
            var critImpact = CritExploi.findOne({ _id: idCExploi });                                                   // 60
                                                                                                                       //
            var impacts = critImpact.impact;                                                                           // 62
            for (var i = 0; i < impacts.length; i++) {                                                                 // 63
                Meteor.call('deletecritExploiImpact', impacts[i]);                                                     // 64
            }                                                                                                          // 65
            return CritExploi.remove({ _id: idCExploi });                                                              // 66
        }                                                                                                              // 67
                                                                                                                       //
        return deleteCritExploi;                                                                                       // 57
    }()                                                                                                                // 57
});                                                                                                                    // 3
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"critSecurit":{"exigence":{"typeExigence":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/enf/critSecurit/exigence/typeExigence/methods.js                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//type critere Exigence                                                                                                // 1
Meteor.methods({                                                                                                       // 2
  'addTypecritExigence': function () {                                                                                 // 3
    function addTypecritExigence(typecE) {                                                                             // 3
      console.log("The method 'addTypecritExigence' has been called !");                                               // 4
      console.log("Type acteur : " + typecE);                                                                          // 5
                                                                                                                       //
      return TypecritExigence.insert({ name: typecE });                                                                // 7
    }                                                                                                                  // 8
                                                                                                                       //
    return addTypecritExigence;                                                                                        // 3
  }(),                                                                                                                 // 3
  'deleteTypecritExigence': function () {                                                                              // 9
    function deleteTypecritExigence(typeCEId) {                                                                        // 9
      console.log("The method 'deleteTypecritExigence' has been called !");                                            // 10
      console.log("Id Type Acteur : " + typeCEId);                                                                     // 11
                                                                                                                       //
      return TypecritExigence.remove({ _id: typeCEId });                                                               // 13
    }                                                                                                                  // 14
                                                                                                                       //
    return deleteTypecritExigence;                                                                                     // 9
  }()                                                                                                                  // 9
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/enf/critSecurit/exigence/methods.js                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Exigence                                                                                                             // 1
Meteor.methods({                                                                                                       // 2
    'addcritSecuExigence': function () {                                                                               // 3
        function addcritSecuExigence(idtypeExigence) {                                                                 // 3
            console.log("The method 'addcritSecuExigence' has been called !");                                         // 4
            console.log("\tID type Exigence : " + idtypeExigence);                                                     // 5
                                                                                                                       //
            return CritSecuExigence.insert({ typeExigence: idtypeExigence, description: "", createAt: new Date() });   // 7
        }                                                                                                              // 8
                                                                                                                       //
        return addcritSecuExigence;                                                                                    // 3
    }(),                                                                                                               // 3
    'updatecritSecuExigence': function () {                                                                            // 9
        function updatecritSecuExigence(idSecuExigence, description) {                                                 // 9
            console.log("The method 'updatecritSecuExigence' has been called !");                                      // 10
            console.log("\tID Secu Exigence : " + idSecuExigence);                                                     // 11
            console.log("\tdescription : " + description);                                                             // 12
                                                                                                                       //
            return CritSecuExigence.update({ _id: idSecuExigence }, { $set: { description: description } });           // 14
        }                                                                                                              // 15
                                                                                                                       //
        return updatecritSecuExigence;                                                                                 // 9
    }(),                                                                                                               // 9
    'deletecritSecuExigence': function () {                                                                            // 16
        function deletecritSecuExigence(idSecuExigence) {                                                              // 16
            console.log("The method 'deletecritSecuExigence' has been called !");                                      // 17
            console.log("\tID Secu Exigence : " + idSecuExigence);                                                     // 18
                                                                                                                       //
            return CritSecuExigence.remove({ _id: idSecuExigence });                                                   // 20
        }                                                                                                              // 21
                                                                                                                       //
        return deletecritSecuExigence;                                                                                 // 16
    }()                                                                                                                // 16
                                                                                                                       //
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/enf/critSecurit/methods.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Critere Securite                                                                                                     // 1
                                                                                                                       //
Meteor.methods({                                                                                                       // 3
    'addCritSecuritEmpty': function () {                                                                               // 4
        function addCritSecuritEmpty() {                                                                               // 4
            console.log("The method 'addCritSecuritEmpty' has been called !");                                         // 5
            var typeexigence = [];                                                                                     // 6
            TypecritExigence.find().forEach(function (typeCS) {                                                        // 7
                typeexigence.push(typeCS._id);                                                                         // 8
            });                                                                                                        // 9
            var exigence = [];                                                                                         // 10
            for (var i = 0; i < typeexigence.length; i++) {                                                            // 11
                var cs = Meteor.call('addcritSecuExigence', typeexigence[i]);                                          // 12
                console.log(cs);                                                                                       // 13
                exigence.push(cs);                                                                                     // 14
            }                                                                                                          // 15
            return CritSecurite.insert({ exigence: exigence, etude: "", createAt: new Date() });                       // 16
        }                                                                                                              // 17
                                                                                                                       //
        return addCritSecuritEmpty;                                                                                    // 4
    }(),                                                                                                               // 4
    'updateCritSecurit': function () {                                                                                 // 18
        function updateCritSecurit(idCSecurite, etude) {                                                               // 18
            console.log("The method 'updateCritSecurit' has been called !");                                           // 19
            console.log("\tid critere securite : " + idCSecurite);                                                     // 20
            console.log("\tEtude : " + etude);                                                                         // 21
                                                                                                                       //
            return CritSecurite.update({ _id: idCSecurite }, { $set: { etude: etude } });                              // 23
        }                                                                                                              // 24
                                                                                                                       //
        return updateCritSecurit;                                                                                      // 18
    }(),                                                                                                               // 18
                                                                                                                       //
    'deleteCritSecurit': function () {                                                                                 // 26
        function deleteCritSecurit(idCSecurite) {                                                                      // 26
            console.log("The method 'deleteCritSecurit' has been called !");                                           // 27
            console.log("\tid critere securite : " + idCSecurite);                                                     // 28
            var critSecuExigence = CritSecurite.findOne({ _id: idCSecurite });                                         // 29
            var exigences = critSecuExigence.exigence;                                                                 // 30
            for (var i = 0; i < exigences.length; i++) {                                                               // 31
                Meteor.call('deletecritSecuExigence', exigences[i]);                                                   // 32
            }                                                                                                          // 33
            return CritSecurite.remove({ _id: idCSecurite });                                                          // 34
        }                                                                                                              // 35
                                                                                                                       //
        return deleteCritSecurit;                                                                                      // 26
    }()                                                                                                                // 26
});                                                                                                                    // 3
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"critPerfor":{"typeTempsdereponse":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/enf/critPerfor/typeTempsdereponse/methods.js                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//type temps de réponse                                                                                                // 1
Meteor.methods({                                                                                                       // 2
    'addTypeTempsdeReponse': function () {                                                                             // 3
        function addTypeTempsdeReponse(typetdr) {                                                                      // 3
            console.log("The method 'addTypeAppmetier' has been called !");                                            // 4
            console.log("\tType tdr : " + typetdr);                                                                    // 5
                                                                                                                       //
            return CritTypeTempsReponse.insert({ name: typetdr });                                                     // 7
        }                                                                                                              // 8
                                                                                                                       //
        return addTypeTempsdeReponse;                                                                                  // 3
    }(),                                                                                                               // 3
    deleteTypeTempsdeReponse: function () {                                                                            // 9
        function deleteTypeTempsdeReponse(idtypetdr) {                                                                 // 9
            console.log("The method 'deleteTypeTempsdeReponse' has been called !");                                    // 10
            console.log("\tID tdr : " + idtypetdr);                                                                    // 11
                                                                                                                       //
            return CritTypeTempsReponse.remove({ _id: idtypetdr });                                                    // 13
        }                                                                                                              // 14
                                                                                                                       //
        return deleteTypeTempsdeReponse;                                                                               // 9
    }()                                                                                                                // 9
                                                                                                                       //
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/enf/critPerfor/methods.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Critère de performance                                                                                               // 1
Meteor.methods({                                                                                                       // 2
    'addCritPerf': function () {                                                                                       // 3
        function addCritPerf() {                                                                                       // 3
            console.log("The method 'addCritSecuritEmpty' has been called !");                                         // 4
            var typetdr = [];                                                                                          // 5
            CritTypeTempsReponse.find().forEach(function (typetdrc) {                                                  // 6
                typetdr.push(typetdrc._id);                                                                            // 7
            });                                                                                                        // 8
                                                                                                                       //
            var perf = [];                                                                                             // 10
            for (var i = 0; i < typetdr.length; i++) {                                                                 // 11
                var tdr = CritPerformance.insert({ tdr: typetdr[i], standard: 0, charge: 0, createAt: new Date() });   // 12
                perf.push(tdr);                                                                                        // 13
            }                                                                                                          // 14
            return perf;                                                                                               // 15
        }                                                                                                              // 16
                                                                                                                       //
        return addCritPerf;                                                                                            // 3
    }(),                                                                                                               // 3
    'updateCritPerformance': function () {                                                                             // 17
        function updateCritPerformance(idcritPerf, standard, charge) {                                                 // 17
            console.log("The method 'updateCritPerformance' has been called !");                                       // 18
            console.log("\tid critere perf : " + idcritPerf);                                                          // 19
            console.log("\tstandard : " + standard);                                                                   // 20
            console.log("\tcharge : " + charge);                                                                       // 21
                                                                                                                       //
            return CritPerformance.update({ _id: idcritPerf }, { $set: { standard: standard, charge: charge } });      // 23
        }                                                                                                              // 24
                                                                                                                       //
        return updateCritPerformance;                                                                                  // 17
    }(),                                                                                                               // 17
    'deleteCritPerformance': function () {                                                                             // 25
        function deleteCritPerformance(idcritPerf) {                                                                   // 25
            console.log("The method 'deleteCritPerformance' has been called !");                                       // 26
            console.log("\tid critere perf : " + idcritPerf);                                                          // 27
                                                                                                                       //
            return CritPerformance.remove({ _id: idcritPerf });                                                        // 29
        }                                                                                                              // 30
                                                                                                                       //
        return deleteCritPerformance;                                                                                  // 25
    }()                                                                                                                // 25
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/enf/methods.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Exigence non fonctionnelle                                                                                           // 1
                                                                                                                       //
Meteor.methods({                                                                                                       // 3
    'addEnfEmpty': function () {                                                                                       // 4
        function addEnfEmpty() {                                                                                       // 4
            console.log("The method 'addEnfEmpty' has been called !");                                                 // 5
                                                                                                                       //
            var critSecurite = Meteor.call('addCritSecuritEmpty');                                                     // 7
            var critDispo = Meteor.call('addcritDispoEmpty');                                                          // 8
            var critPerformance = Meteor.call('addCritPerf');                                                          // 9
            var critExploi = Meteor.call('addCritExploiEmpty');                                                        // 10
                                                                                                                       //
            return Enf.insert({ critSecurite: critSecurite,                                                            // 12
                critDispo: critDispo,                                                                                  // 13
                critPerformance: critPerformance,                                                                      // 14
                critExploi: critExploi                                                                                 // 15
            });                                                                                                        // 12
        }                                                                                                              // 17
                                                                                                                       //
        return addEnfEmpty;                                                                                            // 4
    }(),                                                                                                               // 4
    'deleteEnf': function () {                                                                                         // 18
        function deleteEnf(idEnf) {                                                                                    // 18
            console.log("The method 'deleteEnf' has been called !");                                                   // 19
            console.log("ID ENF : " + idEnf);                                                                          // 20
            var enf = Enf.findOne({ _id: idEnf });                                                                     // 21
                                                                                                                       //
            Meteor.call('deleteCritSecurit', enf.critSecurite);                                                        // 23
            Meteor.call('deleteSecuritDispo', enf.critDispo);                                                          // 24
                                                                                                                       //
            for (var i = 0; i < enf.critPerformance.length; i++) {                                                     // 26
                console.log(enf.critPerformance[i]);                                                                   // 27
            }                                                                                                          // 28
                                                                                                                       //
            return Enf.remove({ _id: idEnf });                                                                         // 30
        }                                                                                                              // 31
                                                                                                                       //
        return deleteEnf;                                                                                              // 18
    }()                                                                                                                // 18
                                                                                                                       //
});                                                                                                                    // 3
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"crt":{"postedetravail":{"typePostedetravail":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/crt/postedetravail/typePostedetravail/methods.js                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//type de poste                                                                                                        // 1
Meteor.methods({                                                                                                       // 2
  'addTypePdT': function () {                                                                                          // 3
    function addTypePdT(typePdT) {                                                                                     // 3
      console.log("The method 'addTypePdT' has been called !");                                                        // 4
      console.log("Type Poste de travail : " + typePdT);                                                               // 5
                                                                                                                       //
      return TypePostdTravail.insert({ name: typePdT });                                                               // 7
    }                                                                                                                  // 8
                                                                                                                       //
    return addTypePdT;                                                                                                 // 3
  }(),                                                                                                                 // 3
  'deleteTypePdT': function () {                                                                                       // 9
    function deleteTypePdT(idTypePdT) {                                                                                // 9
      console.log("The method 'deleteTypePdT' has been called !");                                                     // 10
      console.log("Id Type Poste de travail : " + idTypePdT);                                                          // 11
                                                                                                                       //
      return TypePostdTravail.remove({ _id: idTypePdT });                                                              // 13
    }                                                                                                                  // 14
                                                                                                                       //
    return deleteTypePdT;                                                                                              // 9
  }()                                                                                                                  // 9
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/crt/postedetravail/methods.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Poste de travail                                                                                                     // 1
Meteor.methods({                                                                                                       // 2
    'addPdTEmpty': function () {                                                                                       // 3
        function addPdTEmpty() {                                                                                       // 3
            console.log("The method 'addPdTEmpty' has been called!");                                                  // 4
            return PostTravail.insert({ typePdT: "", name: "", createAt: new Date() });                                // 5
        }                                                                                                              // 6
                                                                                                                       //
        return addPdTEmpty;                                                                                            // 3
    }(),                                                                                                               // 3
    'updatePdT': function () {                                                                                         // 7
        function updatePdT(idPdT, typePdT, name) {                                                                     // 7
            console.log("The method 'updatePdT' has been called!");                                                    // 8
            console.log("ID Poste de Travail :" + idPdT);                                                              // 9
            console.log("ID TYPE PDT :" + typePdT);                                                                    // 10
            return PostTravail.update({ _id: idPdT }, { $set: { typePdT: typePdT, name: name } });                     // 11
        }                                                                                                              // 12
                                                                                                                       //
        return updatePdT;                                                                                              // 7
    }(),                                                                                                               // 7
    'deletePdT': function () {                                                                                         // 13
        function deletePdT(idPdT) {                                                                                    // 13
            console.log("The method 'deletePdT' has been called!");                                                    // 14
            console.log("Objectif ID : " + idPdT);                                                                     // 15
                                                                                                                       //
            Crt.find().forEach(function (cont) {                                                                       // 17
                Meteor.call('deletePdTToCrt', cont._id, idPdT);                                                        // 18
            });                                                                                                        // 19
            return PostTravail.remove(idPdT);                                                                          // 20
        }                                                                                                              // 21
                                                                                                                       //
        return deletePdT;                                                                                              // 13
    }(),                                                                                                               // 13
    'deletePdTById': function () {                                                                                     // 22
        function deletePdTById(idPdT) {                                                                                // 22
            console.log("The method 'deletePdTById' has been called!");                                                // 23
            console.log("Objectif ID : " + idPdT);                                                                     // 24
                                                                                                                       //
            return PostTravail.remove(idPdT);                                                                          // 26
        }                                                                                                              // 27
                                                                                                                       //
        return deletePdTById;                                                                                          // 22
    }()                                                                                                                // 22
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"volumetrie":{"donnees":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/crt/volumetrie/donnees/methods.js                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Volumétrie données                                                                                                   // 1
Meteor.methods({                                                                                                       // 2
    'addVolDonneeEmpty': function () {                                                                                 // 3
        function addVolDonneeEmpty() {                                                                                 // 3
            console.log("The method 'addVolDonneesEmpty' has been called !");                                          // 4
            return VolDonnee.insert({ d1: 0, d2: 0, d3: 0, d4: 0, total: 0 });                                         // 5
        }                                                                                                              // 6
                                                                                                                       //
        return addVolDonneeEmpty;                                                                                      // 3
    }(),                                                                                                               // 3
    'updateVolDonneEmpty': function () {                                                                               // 7
        function updateVolDonneEmpty(idVolDonnee, d1, d2, d3, d4) {                                                    // 7
            console.log("The method 'updateVolDonneEmpty' has been called!");                                          // 8
            console.log("\tVolumetrie donnee ID : " + idVolDonnee);                                                    // 9
            console.log("\tD1 : " + d1);                                                                               // 10
            console.log("\tD2 : " + d2);                                                                               // 11
            console.log("\tD3 : " + d3);                                                                               // 12
            console.log("\tD4 : " + d4);                                                                               // 13
            var total = (d1 * d4 + d2 * d3 * d4) / 1000;                                                               // 14
            return VolDonnee.update({ _id: idVolDonnee }, { $set: { d1: d1, d2: d2, d3: d3, d4: d4, total: total } });
        }                                                                                                              // 16
                                                                                                                       //
        return updateVolDonneEmpty;                                                                                    // 7
    }(),                                                                                                               // 7
    'deleteVolDonnee': function () {                                                                                   // 17
        function deleteVolDonnee(idVolDonnee) {                                                                        // 17
            console.log("The method 'deleteVolDonnee' has been called!");                                              // 18
            console.log("\tID Volumetrie Donnee : " + idVolDonnee);                                                    // 19
                                                                                                                       //
            return VolDonnee.remove(idVolDonnee);                                                                      // 21
        }                                                                                                              // 22
                                                                                                                       //
        return deleteVolDonnee;                                                                                        // 17
    }()                                                                                                                // 17
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"fichiers":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/crt/volumetrie/fichiers/methods.js                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Volumétrie fichier                                                                                                   // 1
Meteor.methods({                                                                                                       // 2
    'addVolFichierEmpty': function () {                                                                                // 3
        function addVolFichierEmpty() {                                                                                // 3
            console.log("The method 'addVolFichierEmpty' has been called !");                                          // 4
            return VolFichier.insert({ f1: 0, f2: 0, f3: 0, total: 0 });                                               // 5
        }                                                                                                              // 6
                                                                                                                       //
        return addVolFichierEmpty;                                                                                     // 3
    }(),                                                                                                               // 3
    'updateVolFichier': function () {                                                                                  // 7
        function updateVolFichier(idVolDonnee, f1, f2, f3, d1, d2) {                                                   // 7
            console.log("The method 'updateVolFichierEmpty' has been called!");                                        // 8
            console.log("\tVolumetrie fichier ID : " + idVolDonnee);                                                   // 9
            console.log("\tF1 : " + f1);                                                                               // 10
            console.log("\tF2 : " + f2);                                                                               // 11
            console.log("\tF3 : " + f3);                                                                               // 12
            var total = (d1 * f1 * f3 + d2 * f1 * f2 * f3) / 1000;                                                     // 13
            return VolFichier.update({ _id: idVolDonnee }, { $set: { f1: f1, f2: f2, f3: f3, total: total } });        // 14
        }                                                                                                              // 15
                                                                                                                       //
        return updateVolFichier;                                                                                       // 7
    }(),                                                                                                               // 7
    'deleteVolFichier': function () {                                                                                  // 16
        function deleteVolFichier(idVolDonnee) {                                                                       // 16
            console.log("The method 'deleteVolFichier' has been called!");                                             // 17
            console.log("\tID Volumetrie fichier : " + idVolDonnee);                                                   // 18
            return VolFichier.remove(idVolDonnee);                                                                     // 19
        }                                                                                                              // 20
                                                                                                                       //
        return deleteVolFichier;                                                                                       // 16
    }()                                                                                                                // 16
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"reduction":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/crt/volumetrie/reduction/methods.js                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Réduction Volume                                                                                                     // 1
Meteor.methods({                                                                                                       // 2
    'addRedVolumEmpty': function () {                                                                                  // 3
        function addRedVolumEmpty() {                                                                                  // 3
            console.log("The method 'addRedVolumEmpty' has been called !");                                            // 4
            return RedVol.insert({ c1: false, c2: false });                                                            // 5
        }                                                                                                              // 6
                                                                                                                       //
        return addRedVolumEmpty;                                                                                       // 3
    }(),                                                                                                               // 3
    'updateRedVol': function () {                                                                                      // 7
        function updateRedVol(idRedVol, c1, c2) {                                                                      // 7
            console.log("The method 'updateRedVolEmpty' has been called!");                                            // 8
            console.log("\tReduction Volume ID : " + idRedVol);                                                        // 9
            console.log("\tC1 : " + c1);                                                                               // 10
            console.log("\tC2 : " + c2);                                                                               // 11
            if (c1 === "oui") {                                                                                        // 12
                c1 = true;                                                                                             // 13
            } else {                                                                                                   // 14
                c1 = false;                                                                                            // 16
            }                                                                                                          // 17
                                                                                                                       //
            if (c2 === "oui") {                                                                                        // 19
                c2 = true;                                                                                             // 20
            } else {                                                                                                   // 21
                c2 = false;                                                                                            // 23
            }                                                                                                          // 24
            return RedVol.update({ _id: idRedVol }, { $set: { c1: c1, c2: c2 } });                                     // 25
        }                                                                                                              // 26
                                                                                                                       //
        return updateRedVol;                                                                                           // 7
    }(),                                                                                                               // 7
    'deleteRedVol': function () {                                                                                      // 27
        function deleteRedVol(idRedVol) {                                                                              // 27
            console.log("The method 'deleteRedVol' has been called!");                                                 // 28
            console.log("\tID Reduction Volume : " + idRedVol);                                                        // 29
                                                                                                                       //
            return RedVol.remove(idRedVol);                                                                            // 32
        }                                                                                                              // 33
                                                                                                                       //
        return deleteRedVol;                                                                                           // 27
    }()                                                                                                                // 27
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/crt/volumetrie/methods.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Volumetrie                                                                                                           // 1
Meteor.methods({                                                                                                       // 2
    'addVolumetrieEmpty': function () {                                                                                // 3
        function addVolumetrieEmpty() {                                                                                // 3
            console.log("The method 'addVolumetrieEmpty' has been called!");                                           // 4
            var volDonnee = Meteor.call('addVolDonneeEmpty');                                                          // 5
            var volFichier = Meteor.call('addVolFichierEmpty');                                                        // 6
            var redVol = Meteor.call('addRedVolumEmpty');                                                              // 7
                                                                                                                       //
            return Volumetrie.insert({ volDonnee: volDonnee, volFichier: volFichier, redVol: redVol, createAt: new Date() });
        }                                                                                                              // 10
                                                                                                                       //
        return addVolumetrieEmpty;                                                                                     // 3
    }(),                                                                                                               // 3
    'deleteVolumetrie': function () {                                                                                  // 11
        function deleteVolumetrie(idVolumetrie) {                                                                      // 11
            console.log("The method 'deleteVolumetrie' has been called!");                                             // 12
            console.log("\tVolumetrie ID : " + idVolumetrie);                                                          // 13
                                                                                                                       //
            var vol = Volumetrie.findOne({ _id: idVolumetrie });                                                       // 15
            Meteor.call('deleteVolDonnee', vol.volDonnee);                                                             // 16
            Meteor.call('deleteVolFichier', vol.volFichier);                                                           // 17
            Meteor.call('deleteRedVol', vol.redVol);                                                                   // 18
                                                                                                                       //
            return Volumetrie.remove({ _id: idVolumetrie });                                                           // 20
        }                                                                                                              // 21
                                                                                                                       //
        return deleteVolumetrie;                                                                                       // 11
    }()                                                                                                                // 11
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"dependance":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/crt/dependance/methods.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Dependance                                                                                                           // 1
Meteor.methods({                                                                                                       // 2
    'addDependanceEmpty': function () {                                                                                // 3
        function addDependanceEmpty() {                                                                                // 3
            console.log("The method 'addDependanceEmpty' has been called!");                                           // 4
            return Dependance.insert({ si: "", consommateur: false, fournisseur: false, createAt: new Date() });       // 5
        }                                                                                                              // 6
                                                                                                                       //
        return addDependanceEmpty;                                                                                     // 3
    }(),                                                                                                               // 3
    'updateDependance': function () {                                                                                  // 7
        function updateDependance(idDependance, si, consommateur, fournisseur) {                                       // 7
            console.log("The method 'updateDependance' has been called!");                                             // 8
            console.log("Objectif ID : " + idDependance);                                                              // 9
            console.log("\tSI :" + si);                                                                                // 10
            console.log("\tconsommateur :" + consommateur);                                                            // 11
            console.log("\tfournisseur :" + fournisseur);                                                              // 12
                                                                                                                       //
            return Dependance.update({ _id: idDependance }, { $set: { si: si, consommateur: consommateur, fournisseur: fournisseur } });
        }                                                                                                              // 15
                                                                                                                       //
        return updateDependance;                                                                                       // 7
    }(),                                                                                                               // 7
    'deleteDependance': function () {                                                                                  // 16
        function deleteDependance(idDependance) {                                                                      // 16
            console.log("The method 'deleteDependance' has been called!");                                             // 17
            console.log("\tObjectif ID : " + idDependance);                                                            // 18
                                                                                                                       //
            Crt.find().forEach(function (cont) {                                                                       // 20
                Meteor.call('deleteDependanceToCrt', cont._id, idDependance);                                          // 21
            });                                                                                                        // 22
            return Dependance.remove(idDependance);                                                                    // 23
        }                                                                                                              // 24
                                                                                                                       //
        return deleteDependance;                                                                                       // 16
    }(),                                                                                                               // 16
    'deleteDependanceById': function () {                                                                              // 25
        function deleteDependanceById(idDependance) {                                                                  // 25
            console.log("The method 'deleteDependanceById' has been called!");                                         // 26
            console.log("\tObjectif ID : " + idDependance);                                                            // 27
                                                                                                                       //
            return Dependance.remove(idDependance);                                                                    // 29
        }                                                                                                              // 30
                                                                                                                       //
        return deleteDependanceById;                                                                                   // 25
    }()                                                                                                                // 25
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"hebergement":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/crt/hebergement/methods.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Hebergement                                                                                                          // 1
Meteor.methods({                                                                                                       // 2
    'addHebergementEmpty': function () {                                                                               // 3
        function addHebergementEmpty() {                                                                               // 3
            console.log("The method 'addHebergementEmpty' has been called!");                                          // 4
            return Hebergement.insert({ name: "", createAt: new Date() });                                             // 5
        }                                                                                                              // 6
                                                                                                                       //
        return addHebergementEmpty;                                                                                    // 3
    }(),                                                                                                               // 3
    'updateHebergement': function () {                                                                                 // 7
        function updateHebergement(idHebergement, name) {                                                              // 7
            console.log("The method 'updateHebergement' has been called!");                                            // 8
            console.log("Objectif ID : " + idHebergement);                                                             // 9
            console.log("Champs input :" + name);                                                                      // 10
                                                                                                                       //
            return Hebergement.update({ _id: idHebergement }, { $set: { name: name } });                               // 12
        }                                                                                                              // 13
                                                                                                                       //
        return updateHebergement;                                                                                      // 7
    }(),                                                                                                               // 7
    'deleteHebergement': function () {                                                                                 // 14
        function deleteHebergement(idHebergement) {                                                                    // 14
            console.log("The method 'deleteHebergement' has been called!");                                            // 15
            console.log("Objectif ID : " + idHebergement);                                                             // 16
                                                                                                                       //
            Crt.find().forEach(function (cont) {                                                                       // 18
                Meteor.call('deleteHebergementToCrt', cont._id, idHebergement);                                        // 19
            });                                                                                                        // 20
            return Hebergement.remove(idHebergement);                                                                  // 21
        }                                                                                                              // 22
                                                                                                                       //
        return deleteHebergement;                                                                                      // 14
    }(),                                                                                                               // 14
    'deleteHebergementById': function () {                                                                             // 23
        function deleteHebergementById(idHebergement) {                                                                // 23
            console.log("The method 'deleteHebergementById' has been called!");                                        // 24
            console.log("Objectif ID : " + idHebergement);                                                             // 25
                                                                                                                       //
            return Hebergement.remove(idHebergement);                                                                  // 27
        }                                                                                                              // 28
                                                                                                                       //
        return deleteHebergementById;                                                                                  // 23
    }()                                                                                                                // 23
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"reglementaire":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/crt/reglementaire/methods.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Reglementaire                                                                                                        // 1
Meteor.methods({                                                                                                       // 2
    'addReglementaireEmpty': function () {                                                                             // 3
        function addReglementaireEmpty() {                                                                             // 3
            console.log("The method 'addReglementaireEmpty' has been called!");                                        // 4
            return Reglementaire.insert({ name: "", createAt: new Date() });                                           // 5
        }                                                                                                              // 6
                                                                                                                       //
        return addReglementaireEmpty;                                                                                  // 3
    }(),                                                                                                               // 3
    'updateReglementaire': function () {                                                                               // 7
        function updateReglementaire(idReglementaire, name) {                                                          // 7
            console.log("The method 'updateReglementaire' has been called!");                                          // 8
            console.log("Objectif ID : " + idReglementaire);                                                           // 9
            console.log("Champs input :" + name);                                                                      // 10
                                                                                                                       //
            return Reglementaire.update({ _id: idReglementaire }, { $set: { name: name } });                           // 12
        }                                                                                                              // 13
                                                                                                                       //
        return updateReglementaire;                                                                                    // 7
    }(),                                                                                                               // 7
    'deleteReglementaire': function () {                                                                               // 14
        function deleteReglementaire(idReglementaire) {                                                                // 14
            console.log("The method 'deleteReglementaire' has been called!");                                          // 15
            console.log("Objectif ID : " + idReglementaire);                                                           // 16
                                                                                                                       //
            Crt.find().forEach(function (cont) {                                                                       // 18
                Meteor.call('deleteReglementaireToCrt', cont._id, idReglementaire);                                    // 19
            });                                                                                                        // 20
            return Reglementaire.remove(idReglementaire);                                                              // 21
        }                                                                                                              // 22
                                                                                                                       //
        return deleteReglementaire;                                                                                    // 14
    }(),                                                                                                               // 14
    'deleteReglementaireById': function () {                                                                           // 23
        function deleteReglementaireById(idReglementaire) {                                                            // 23
            console.log("The method 'deleteReglementaireById' has been called!");                                      // 24
            console.log("Objectif ID : " + idReglementaire);                                                           // 25
                                                                                                                       //
            return Reglementaire.remove(idReglementaire);                                                              // 27
        }                                                                                                              // 28
                                                                                                                       //
        return deleteReglementaireById;                                                                                // 23
    }()                                                                                                                // 23
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"securite":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/crt/securite/methods.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Securite                                                                                                             // 1
Meteor.methods({                                                                                                       // 2
    'addSecuriteEmpty': function () {                                                                                  // 3
        function addSecuriteEmpty() {                                                                                  // 3
            console.log("The method 'addSecuriteEmpty' has been called!");                                             // 4
            return Securite.insert({ name: "", createAt: new Date() });                                                // 5
        }                                                                                                              // 6
                                                                                                                       //
        return addSecuriteEmpty;                                                                                       // 3
    }(),                                                                                                               // 3
    'updateSecurite': function () {                                                                                    // 7
        function updateSecurite(idSecurite, name) {                                                                    // 7
            console.log("The method 'updateSecurite' has been called!");                                               // 8
            console.log("Objectif ID : " + idSecurite);                                                                // 9
            console.log("Champs input :" + name);                                                                      // 10
                                                                                                                       //
            return Securite.update({ _id: idSecurite }, { $set: { name: name } });                                     // 12
        }                                                                                                              // 13
                                                                                                                       //
        return updateSecurite;                                                                                         // 7
    }(),                                                                                                               // 7
    'deleteSecurite': function () {                                                                                    // 14
        function deleteSecurite(idSecurite) {                                                                          // 14
            console.log("The method 'deleteReglementaire' has been called!");                                          // 15
            console.log("Objectif ID : " + idSecurite);                                                                // 16
                                                                                                                       //
            Crt.find().forEach(function (cont) {                                                                       // 18
                Meteor.call('deleteSecuriteToCrt', cont._id, idSecurite);                                              // 19
            });                                                                                                        // 20
            return Securite.remove(idSecurite);                                                                        // 21
        }                                                                                                              // 22
                                                                                                                       //
        return deleteSecurite;                                                                                         // 14
    }(),                                                                                                               // 14
    'deleteSecuriteById': function () {                                                                                // 23
        function deleteSecuriteById(idSecurite) {                                                                      // 23
            console.log("The method 'deleteSecuriteById' has been called!");                                           // 24
            console.log("Objectif ID : " + idSecurite);                                                                // 25
                                                                                                                       //
            return Securite.remove(idSecurite);                                                                        // 27
        }                                                                                                              // 28
                                                                                                                       //
        return deleteSecuriteById;                                                                                     // 23
    }()                                                                                                                // 23
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/crt/methods.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//CONT                                                                                                                 // 1
Meteor.methods({                                                                                                       // 2
    'addCrtEmpty': function () {                                                                                       // 3
        function addCrtEmpty() {                                                                                       // 3
            console.log("The method 'addCrtEmpty' has been called !");                                                 // 4
            var volumetrie = Meteor.call('addVolumetrieEmpty');                                                        // 5
                                                                                                                       //
            return Crt.insert({ reglementaire: [],                                                                     // 7
                securite: [],                                                                                          // 8
                dependance: [],                                                                                        // 9
                volumetrie: volumetrie,                                                                                // 10
                hebergement: [],                                                                                       // 11
                postedetravail: []                                                                                     // 12
            });                                                                                                        // 7
        }                                                                                                              // 14
                                                                                                                       //
        return addCrtEmpty;                                                                                            // 3
    }(),                                                                                                               // 3
    // REGLEMENTAIRE                                                                                                   // 15
    'addReglementaireToCrt': function () {                                                                             // 16
        function addReglementaireToCrt(idCrt, idReglementaire) {                                                       // 16
            console.log("The method 'addReglementaireToCont' has been called !");                                      // 17
            console.log("Id Crt : " + idCrt);                                                                          // 18
            console.log("id Reglementaire : " + idReglementaire);                                                      // 19
                                                                                                                       //
            var crt = Crt.findOne({ _id: idCrt });                                                                     // 21
            var crtReglementaire = crt.reglementaire;                                                                  // 22
            var i = crtReglementaire.indexOf(idReglementaire);                                                         // 23
                                                                                                                       //
            if (i == -1) {                                                                                             // 25
                crtReglementaire.push(idReglementaire);                                                                // 26
                Crt.update({ _id: idCrt }, { $set: { reglementaire: crtReglementaire } });                             // 27
            }                                                                                                          // 28
        }                                                                                                              // 29
                                                                                                                       //
        return addReglementaireToCrt;                                                                                  // 16
    }(),                                                                                                               // 16
    'deleteReglementaireToCrt': function () {                                                                          // 30
        function deleteReglementaireToCrt(idCrt, idReglementaire) {                                                    // 30
            console.log("The method 'deleteReglementaireToCrt' has been called !");                                    // 31
            console.log("Id Crt : " + idCrt);                                                                          // 32
            console.log("id Reglementaire : " + idReglementaire);                                                      // 33
                                                                                                                       //
            var crt = Crt.findOne({ _id: idCrt });                                                                     // 35
            var crtReglementaire = crt.reglementaire;                                                                  // 36
            var i = crtReglementaire.indexOf(idReglementaire);                                                         // 37
                                                                                                                       //
            if (i != -1) {                                                                                             // 39
                Meteor.call('deleteReglementaireById', idReglementaire);                                               // 40
                crtReglementaire.splice(i, 1);                                                                         // 41
                Crt.update({ _id: idCrt }, { $set: { reglementaire: crtReglementaire } });                             // 42
            }                                                                                                          // 43
        }                                                                                                              // 44
                                                                                                                       //
        return deleteReglementaireToCrt;                                                                               // 30
    }(),                                                                                                               // 30
    //Securite                                                                                                         // 45
    'addSecuriteToCrt': function () {                                                                                  // 46
        function addSecuriteToCrt(idCrt, idSecurite) {                                                                 // 46
            console.log("The method 'addSecuriteToCrt' has been called !");                                            // 47
            console.log("Id Crt : " + idCrt);                                                                          // 48
            console.log("id Securité : " + idSecurite);                                                                // 49
                                                                                                                       //
            var crt = Crt.findOne({ _id: idCrt });                                                                     // 51
            var crtSecurite = crt.securite;                                                                            // 52
            var i = crtSecurite.indexOf(idSecurite);                                                                   // 53
                                                                                                                       //
            if (i == -1) {                                                                                             // 55
                crtSecurite.push(idSecurite);                                                                          // 56
                Crt.update({ _id: idCrt }, { $set: { securite: crtSecurite } });                                       // 57
            }                                                                                                          // 58
        }                                                                                                              // 59
                                                                                                                       //
        return addSecuriteToCrt;                                                                                       // 46
    }(),                                                                                                               // 46
    'deleteSecuriteToCrt': function () {                                                                               // 60
        function deleteSecuriteToCrt(idCrt, idSecurite) {                                                              // 60
            console.log("The method 'deleteSecuriteToCrt' has been called !");                                         // 61
            console.log("Id Crt : " + idCrt);                                                                          // 62
            console.log("id Securité : " + idSecurite);                                                                // 63
                                                                                                                       //
            var crt = Crt.findOne({ _id: idCrt });                                                                     // 65
            var crtSecurite = crt.securite;                                                                            // 66
            var i = crtSecurite.indexOf(idSecurite);                                                                   // 67
                                                                                                                       //
            if (i != -1) {                                                                                             // 69
                Meteor.call('deleteSecuriteById', idSecurite);                                                         // 70
                crtSecurite.splice(i, 1);                                                                              // 71
                Crt.update({ _id: idCrt }, { $set: { securite: crtSecurite } });                                       // 72
            }                                                                                                          // 73
        }                                                                                                              // 74
                                                                                                                       //
        return deleteSecuriteToCrt;                                                                                    // 60
    }(),                                                                                                               // 60
    //Dependance                                                                                                       // 75
    'addDependanceToCrt': function () {                                                                                // 76
        function addDependanceToCrt(idCrt, idDependance) {                                                             // 76
            console.log("The method 'addDependanceToCrt' has been called !");                                          // 77
            console.log("Id Crt : " + idCrt);                                                                          // 78
            console.log("id Dependance : " + idDependance);                                                            // 79
                                                                                                                       //
            var crt = Crt.findOne({ _id: idCrt });                                                                     // 81
            var crtDependance = crt.dependance;                                                                        // 82
            var i = crtDependance.indexOf(idDependance);                                                               // 83
                                                                                                                       //
            if (i == -1) {                                                                                             // 85
                crtDependance.push(idDependance);                                                                      // 86
                Crt.update({ _id: idCrt }, { $set: { dependance: crtDependance } });                                   // 87
            }                                                                                                          // 88
        }                                                                                                              // 89
                                                                                                                       //
        return addDependanceToCrt;                                                                                     // 76
    }(),                                                                                                               // 76
    'deleteDependanceToCrt': function () {                                                                             // 90
        function deleteDependanceToCrt(idCrt, idDependance) {                                                          // 90
            console.log("The method 'deleteDependanceToCrt' has been called !");                                       // 91
            console.log("Id Crt : " + idCrt);                                                                          // 92
            console.log("id Dependance : " + idDependance);                                                            // 93
                                                                                                                       //
            var crt = Crt.findOne({ _id: idCrt });                                                                     // 95
            var crtDependance = crt.dependance;                                                                        // 96
            var i = crtDependance.indexOf(idDependance);                                                               // 97
                                                                                                                       //
            if (i != -1) {                                                                                             // 99
                Meteor.call('deleteDependanceById', idDependance);                                                     // 100
                crtDependance.splice(i, 1);                                                                            // 101
                Crt.update({ _id: idCrt }, { $set: { dependance: crtDependance } });                                   // 102
            }                                                                                                          // 103
        }                                                                                                              // 104
                                                                                                                       //
        return deleteDependanceToCrt;                                                                                  // 90
    }(),                                                                                                               // 90
    //Hebergement                                                                                                      // 105
    'addHebergementToCrt': function () {                                                                               // 106
        function addHebergementToCrt(idCrt, idHebergement) {                                                           // 106
            console.log("The method 'addHebergementToCrt' has been called !");                                         // 107
            console.log("Id Crt : " + idCrt);                                                                          // 108
            console.log("id Hebergement : " + idHebergement);                                                          // 109
                                                                                                                       //
            var crt = Crt.findOne({ _id: idCrt });                                                                     // 111
            var crtHebergement = crt.hebergement;                                                                      // 112
            var i = crtHebergement.indexOf(idHebergement);                                                             // 113
                                                                                                                       //
            if (i == -1) {                                                                                             // 115
                crtHebergement.push(idHebergement);                                                                    // 116
                Crt.update({ _id: idCrt }, { $set: { hebergement: crtHebergement } });                                 // 117
            }                                                                                                          // 118
        }                                                                                                              // 119
                                                                                                                       //
        return addHebergementToCrt;                                                                                    // 106
    }(),                                                                                                               // 106
    'deleteHebergementToCrt': function () {                                                                            // 120
        function deleteHebergementToCrt(idCrt, idHebergement) {                                                        // 120
            console.log("The method 'deleteHebergementToCrt' has been called !");                                      // 121
            console.log("Id Crt : " + idCrt);                                                                          // 122
            console.log("id Hebergement : " + idHebergement);                                                          // 123
                                                                                                                       //
            var crt = Crt.findOne({ _id: idCrt });                                                                     // 125
            var crtHebergement = crt.hebergement;                                                                      // 126
            var i = crtHebergement.indexOf(idHebergement);                                                             // 127
                                                                                                                       //
            if (i != -1) {                                                                                             // 129
                Meteor.call('deleteHebergementById', idHebergement);                                                   // 130
                crtHebergement.splice(i, 1);                                                                           // 131
                Crt.update({ _id: idCrt }, { $set: { hebergement: crtHebergement } });                                 // 132
            }                                                                                                          // 133
        }                                                                                                              // 134
                                                                                                                       //
        return deleteHebergementToCrt;                                                                                 // 120
    }(),                                                                                                               // 120
    //Poste de travail                                                                                                 // 135
    'addPdTToCrt': function () {                                                                                       // 136
        function addPdTToCrt(idCrt, idPdT) {                                                                           // 136
            console.log("The method 'addPdTToCrt' has been called !");                                                 // 137
            console.log("\tId Crt : " + idCrt);                                                                        // 138
            console.log("\tid Poste de travail : " + idPdT);                                                           // 139
                                                                                                                       //
            var crt = Crt.findOne({ _id: idCrt });                                                                     // 141
            var postedetravail = crt.postedetravail;                                                                   // 142
            var i = postedetravail.indexOf(idPdT);                                                                     // 143
                                                                                                                       //
            if (i == -1) {                                                                                             // 145
                postedetravail.push(idPdT);                                                                            // 146
                Crt.update({ _id: idCrt }, { $set: { postedetravail: postedetravail } });                              // 147
            }                                                                                                          // 148
        }                                                                                                              // 149
                                                                                                                       //
        return addPdTToCrt;                                                                                            // 136
    }(),                                                                                                               // 136
    'deletePdTToCrt': function () {                                                                                    // 150
        function deletePdTToCrt(idCrt, idPdT) {                                                                        // 150
            console.log("The method 'deletePdTToCrt' has been called !");                                              // 151
            console.log("\tId Crt : " + idCrt);                                                                        // 152
            console.log("\tid Poste de travail : " + idPdT);                                                           // 153
                                                                                                                       //
            var crt = Crt.findOne({ _id: idCrt });                                                                     // 155
            var postedetravail = crt.postedetravail;                                                                   // 156
            var i = postedetravail.indexOf(idPdT);                                                                     // 157
                                                                                                                       //
            if (i != -1) {                                                                                             // 159
                Meteor.call('deletePdTById', idPdT);                                                                   // 160
                postedetravail.splice(i, 1);                                                                           // 161
                Crt.update({ _id: idCrt }, { $set: { postedetravail: postedetravail } });                              // 162
            }                                                                                                          // 163
        }                                                                                                              // 164
                                                                                                                       //
        return deletePdTToCrt;                                                                                         // 150
    }(),                                                                                                               // 150
    'deleteCrt': function () {                                                                                         // 165
        function deleteCrt(idCrt) {                                                                                    // 165
            console.log("The method 'deleteCrt' has been called !");                                                   // 166
            console.log("ID contraintes : " + idCrt);                                                                  // 167
                                                                                                                       //
            var crt = Crt.findOne({ _id: idCrt });                                                                     // 169
                                                                                                                       //
            //Reglementaire                                                                                            // 171
            for (var i = 0; i < crt.reglementaire.length; i++) {                                                       // 172
                Meteor.call('deleteReglementaireToCrt', idCrt, crt.reglementaire[i]);                                  // 173
            }                                                                                                          // 174
            //Securite                                                                                                 // 175
            for (var i = 0; i < crt.securite.length; i++) {                                                            // 176
                Meteor.call('deleteSecuriteToCrt', idCrt, crt.securite[i]);                                            // 177
            }                                                                                                          // 178
            //Dependance                                                                                               // 179
            for (var i = 0; i < crt.dependance.length; i++) {                                                          // 180
                Meteor.call('deleteDependanceToCrt', idCrt, crt.dependance[i]);                                        // 181
            }                                                                                                          // 182
            //Hebergement                                                                                              // 183
            for (var i = 0; i < crt.hebergement.length; i++) {                                                         // 184
                Meteor.call('deleteHebergementToCrt', idCrt, crt.hebergement[i]);                                      // 185
            }                                                                                                          // 186
            //Poste de travail                                                                                         // 187
            for (var i = 0; i < crt.postedetravail.length; i++) {                                                      // 188
                Meteor.call('deletePdTToCrt', idCrt, crt.postedetravail[i]);                                           // 189
            }                                                                                                          // 190
            //Volumetrie                                                                                               // 191
            Meteor.call('deleteVolumetrie', crt.volumetrie);                                                           // 192
                                                                                                                       //
            return Crt.remove({ _id: idCrt });                                                                         // 194
        }                                                                                                              // 195
                                                                                                                       //
        return deleteCrt;                                                                                              // 165
    }()                                                                                                                // 165
                                                                                                                       //
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"esp":{"Enjeux":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/esp/Enjeux/methods.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Enjeux                                                                                                               // 1
Meteor.methods({                                                                                                       // 2
    'addEnjeuxEmpty': function () {                                                                                    // 3
        function addEnjeuxEmpty() {                                                                                    // 3
            console.log("The method 'addEnjeuxEmpty' has been called!");                                               // 4
            return Enjeux.insert({ name: "", createAt: new Date() });                                                  // 5
        }                                                                                                              // 6
                                                                                                                       //
        return addEnjeuxEmpty;                                                                                         // 3
    }(),                                                                                                               // 3
    'updateEnjeux': function () {                                                                                      // 7
        function updateEnjeux(idEnjeux, name) {                                                                        // 7
            console.log("The method 'updateEnjeux' has been called!");                                                 // 8
            console.log("Objectif ID : " + idEnjeux);                                                                  // 9
            console.log("Champs input :" + name);                                                                      // 10
                                                                                                                       //
            return Enjeux.update({ _id: idEnjeux }, { $set: { name: name } });                                         // 12
        }                                                                                                              // 13
                                                                                                                       //
        return updateEnjeux;                                                                                           // 7
    }(),                                                                                                               // 7
    'deleteEnjeux': function () {                                                                                      // 14
        function deleteEnjeux(idEnjeux) {                                                                              // 14
            console.log("The method 'deleteObjectif' has been called!");                                               // 15
            console.log("Objectif ID : " + idEnjeux);                                                                  // 16
            Esp.find().forEach(function (esp) {                                                                        // 17
                Meteor.call('deleteEnjToEsp', esp._id, idEnjeux);                                                      // 18
            });                                                                                                        // 19
            return Enjeux.remove(idEnjeux);                                                                            // 20
        }                                                                                                              // 21
                                                                                                                       //
        return deleteEnjeux;                                                                                           // 14
    }(),                                                                                                               // 14
    'deleteEnjeuxById': function () {                                                                                  // 22
        function deleteEnjeuxById(idEnjeux) {                                                                          // 22
            console.log("The method 'deleteObjectif' has been called!");                                               // 23
            console.log("Objectif ID : " + idEnjeux);                                                                  // 24
                                                                                                                       //
            return Enjeux.remove(idEnjeux);                                                                            // 26
        }                                                                                                              // 27
                                                                                                                       //
        return deleteEnjeuxById;                                                                                       // 22
    }()                                                                                                                // 22
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"Objectifs":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/esp/Objectifs/methods.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Objectifs                                                                                                            // 1
Meteor.methods({                                                                                                       // 2
    'addObjectifEmpty': function () {                                                                                  // 3
        function addObjectifEmpty() {                                                                                  // 3
            console.log("The method 'addObjectifEmpty' has been called!");                                             // 4
            return Objectifs.insert({ name: "", createAt: new Date() });                                               // 5
        }                                                                                                              // 6
                                                                                                                       //
        return addObjectifEmpty;                                                                                       // 3
    }(),                                                                                                               // 3
    'updateObjectif': function () {                                                                                    // 7
        function updateObjectif(idObjectif, name) {                                                                    // 7
            console.log("The method 'updateObjectif' has been called!");                                               // 8
            console.log("Objectif ID : " + idObjectif);                                                                // 9
            console.log("Champs input :" + name);                                                                      // 10
                                                                                                                       //
            return Objectifs.update({ _id: idObjectif }, { $set: { name: name } });                                    // 12
        }                                                                                                              // 13
                                                                                                                       //
        return updateObjectif;                                                                                         // 7
    }(),                                                                                                               // 7
    'deleteObjectif': function () {                                                                                    // 14
        function deleteObjectif(idObjectif) {                                                                          // 14
            console.log("The method 'deleteObjectif' has been called!");                                               // 15
            console.log("Objectif ID : " + idObjectif);                                                                // 16
                                                                                                                       //
            Esp.find().forEach(function (esp) {                                                                        // 18
                Meteor.call('deleteObjToEsp', esp._id, idObjectif);                                                    // 19
            });                                                                                                        // 20
            return Objectifs.remove(idObjectif);                                                                       // 21
        }                                                                                                              // 22
                                                                                                                       //
        return deleteObjectif;                                                                                         // 14
    }(),                                                                                                               // 14
    'deleteObjectifById': function () {                                                                                // 23
        function deleteObjectifById(idObjectif) {                                                                      // 23
            console.log("The method 'deleteObjectifById' has been called !");                                          // 24
            console.log("id objectif : " + idObjectif);                                                                // 25
                                                                                                                       //
            return Objectifs.remove(idObjectif);                                                                       // 27
        }                                                                                                              // 28
                                                                                                                       //
        return deleteObjectifById;                                                                                     // 23
    }()                                                                                                                // 23
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"acteurProjet":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/esp/acteurProjet/methods.js                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Acteur projet                                                                                                        // 1
Meteor.methods({                                                                                                       // 2
  'addActeurProjetEmpty': function () {                                                                                // 3
    function addActeurProjetEmpty() {                                                                                  // 3
      console.log("The method 'addActeurProjetEmpty' has been called !");                                              // 4
                                                                                                                       //
      return ActeurProjet.insert({ nom: "", fonction: "", entite: "", typeActeur: "", createAt: new Date() });         // 6
    }                                                                                                                  // 7
                                                                                                                       //
    return addActeurProjetEmpty;                                                                                       // 3
  }(),                                                                                                                 // 3
  'updateActeurProjet': function () {                                                                                  // 8
    function updateActeurProjet(idAP, nom, fonction, entite, typeActeur) {                                             // 8
      console.log("The method 'updateActeurProjet' has been called !");                                                // 9
      console.log("\tid ActeurProjet : " + idAP);                                                                      // 10
      console.log("\t\tnom : " + nom);                                                                                 // 11
      console.log("\tfonction :" + fonction);                                                                          // 12
      console.log("\tentite : " + entite);                                                                             // 13
      console.log("\tID typeActeur : " + typeActeur);                                                                  // 14
                                                                                                                       //
      return ActeurProjet.update({ _id: idAP }, { $set: { nom: nom, fonction: fonction, entite: entite, typeActeur: typeActeur } });
    }                                                                                                                  // 17
                                                                                                                       //
    return updateActeurProjet;                                                                                         // 8
  }(),                                                                                                                 // 8
  'deleteActeurProjet': function () {                                                                                  // 18
    function deleteActeurProjet(idAP) {                                                                                // 18
      console.log("The method 'deleteActeurProjet' has been called !");                                                // 19
      console.log("\tid ActeurProjet : " + idAP);                                                                      // 20
      Esp.find().forEach(function (esp) {                                                                              // 21
        Meteor.call('deleteAPToEsp', esp._id, idAP);                                                                   // 22
      });                                                                                                              // 23
      return ActeurProjet.remove({ _id: idAP });                                                                       // 24
    }                                                                                                                  // 25
                                                                                                                       //
    return deleteActeurProjet;                                                                                         // 18
  }(),                                                                                                                 // 18
  'deleteActeurProjetById': function () {                                                                              // 26
    function deleteActeurProjetById(idAP) {                                                                            // 26
      console.log("The method 'deleteActeurProjetById' has been called !");                                            // 27
      console.log("\tid ActeurProjet : " + idAP);                                                                      // 28
                                                                                                                       //
      return ActeurProjet.remove({ _id: idAP });                                                                       // 30
    }                                                                                                                  // 31
                                                                                                                       //
    return deleteActeurProjetById;                                                                                     // 26
  }()                                                                                                                  // 26
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"acteurUsager":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/esp/acteurUsager/methods.js                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Acteur usagers                                                                                                       // 1
Meteor.methods({                                                                                                       // 2
  'addActeurUsagerEmpty': function () {                                                                                // 3
    function addActeurUsagerEmpty() {                                                                                  // 3
      console.log("The method 'addActeurUsagerEmpty' has been called !");                                              // 4
                                                                                                                       //
      return ActeurUsager.insert({ name: "", min: 0, rie: 0, ext: 0, pub: 0, createAt: new Date() });                  // 6
    }                                                                                                                  // 7
                                                                                                                       //
    return addActeurUsagerEmpty;                                                                                       // 3
  }(),                                                                                                                 // 3
  'updateActeurUsager': function () {                                                                                  // 8
    function updateActeurUsager(idActeurUsager, name, min, rie, ext, pub) {                                            // 8
      console.log("The method 'updateActeurUsager' has been called !");                                                // 9
      console.log("idActeurUsager : " + idActeurUsager);                                                               // 10
      console.log("name : " + name);                                                                                   // 11
      console.log("min : " + min);                                                                                     // 12
      console.log("rie : " + rie);                                                                                     // 13
      console.log("ext : " + ext);                                                                                     // 14
      console.log("pub : " + pub);                                                                                     // 15
                                                                                                                       //
      return ActeurUsager.update({ _id: idActeurUsager }, { $set: { name: name, min: min, rie: rie, ext: ext, pub: pub } });
    }                                                                                                                  // 18
                                                                                                                       //
    return updateActeurUsager;                                                                                         // 8
  }(),                                                                                                                 // 8
  'deleteActeurUsager': function () {                                                                                  // 19
    function deleteActeurUsager(idActeurUsager) {                                                                      // 19
      console.log("The method 'deleteActeurUsager' has been called !");                                                // 20
      console.log("id Acteur Usager : " + idActeurUsager);                                                             // 21
                                                                                                                       //
      Esp.find().forEach(function (esp) {                                                                              // 23
        Meteor.call('deleteAUToEsp', esp._id, idActeurUsager);                                                         // 24
      });                                                                                                              // 25
      return ActeurUsager.remove({ _id: idActeurUsager });                                                             // 26
    }                                                                                                                  // 27
                                                                                                                       //
    return deleteActeurUsager;                                                                                         // 19
  }(),                                                                                                                 // 19
  'deleteActeurUsagerById': function () {                                                                              // 28
    function deleteActeurUsagerById(idActeurUsager) {                                                                  // 28
      console.log("The method 'deleteActeurUsagerById' has been called !");                                            // 29
      console.log("id Acteur Usager : " + idActeurUsager);                                                             // 30
                                                                                                                       //
      return ActeurUsager.remove({ _id: idActeurUsager });                                                             // 32
    }                                                                                                                  // 33
                                                                                                                       //
    return deleteActeurUsagerById;                                                                                     // 28
  }()                                                                                                                  // 28
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"contexte":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/esp/contexte/methods.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//contexte                                                                                                             // 1
Meteor.methods({                                                                                                       // 2
    'addContexteEmpty': function () {                                                                                  // 3
        function addContexteEmpty() {                                                                                  // 3
            console.log("The method 'addContexteEmpty' has been called!");                                             // 4
            return Contexte.insert({ name: "", createAt: new Date() });                                                // 5
        }                                                                                                              // 6
                                                                                                                       //
        return addContexteEmpty;                                                                                       // 3
    }(),                                                                                                               // 3
    'updateContexte': function () {                                                                                    // 7
        function updateContexte(idContexte, name) {                                                                    // 7
            console.log("The method 'updateContexte' has been called!");                                               // 8
            console.log("Objectif ID : " + idContexte);                                                                // 9
            console.log("Champs input :" + name);                                                                      // 10
                                                                                                                       //
            return Contexte.update({ _id: idContexte }, { $set: { name: name } });                                     // 12
        }                                                                                                              // 13
                                                                                                                       //
        return updateContexte;                                                                                         // 7
    }(),                                                                                                               // 7
    'deleteContexte': function () {                                                                                    // 14
        function deleteContexte(idContexte) {                                                                          // 14
            console.log("The method 'deleteContexte' has been called!");                                               // 15
            console.log("Objectif ID : " + idContexte);                                                                // 16
                                                                                                                       //
            Esp.find().forEach(function (esp) {                                                                        // 18
                Meteor.call('deleteContexteToEsp', esp._id, idContexte);                                               // 19
            });                                                                                                        // 20
            return Contexte.remove(idContexte);                                                                        // 21
        }                                                                                                              // 22
                                                                                                                       //
        return deleteContexte;                                                                                         // 14
    }(),                                                                                                               // 14
    'deleteContexteById': function () {                                                                                // 23
        function deleteContexteById(idContexte) {                                                                      // 23
            console.log("The method 'deleteContexteById' has been called !");                                          // 24
            console.log("id objectif : " + idContexte);                                                                // 25
                                                                                                                       //
            return Contexte.remove(idContexte);                                                                        // 27
        }                                                                                                              // 28
                                                                                                                       //
        return deleteContexteById;                                                                                     // 23
    }()                                                                                                                // 23
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"planningProjet":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/esp/planningProjet/methods.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//contexte                                                                                                             // 1
Meteor.methods({                                                                                                       // 2
    'addPlanningEmpty': function () {                                                                                  // 3
        function addPlanningEmpty() {                                                                                  // 3
            console.log("The method 'addPlanningEmpty' has been called!");                                             // 4
            return Planning.insert({ version: "", date: "", commentaire: "", createAt: new Date() });                  // 5
        }                                                                                                              // 6
                                                                                                                       //
        return addPlanningEmpty;                                                                                       // 3
    }(),                                                                                                               // 3
    'updatePlanning': function () {                                                                                    // 7
        function updatePlanning(idPlanning, version, date, commentaire) {                                              // 7
            console.log("The method 'updatePlanning' has been called!");                                               // 8
            console.log("Objectif ID : " + idPlanning);                                                                // 9
            console.log("\tVersion :" + version);                                                                      // 10
            console.log("\tdate :" + date);                                                                            // 11
            console.log("\tCommentaire :" + commentaire);                                                              // 12
                                                                                                                       //
            return Planning.update({ _id: idPlanning }, { $set: { version: version, date: date, commentaire: commentaire } });
        }                                                                                                              // 15
                                                                                                                       //
        return updatePlanning;                                                                                         // 7
    }(),                                                                                                               // 7
    'deletePlanning': function () {                                                                                    // 16
        function deletePlanning(idPlanning) {                                                                          // 16
            console.log("The method 'deletePlanning' has been called!");                                               // 17
            console.log("Objectif ID : " + idPlanning);                                                                // 18
                                                                                                                       //
            Esp.find().forEach(function (esp) {                                                                        // 20
                Meteor.call('deletePlanningToEsp', esp._id, idPlanning);                                               // 21
            });                                                                                                        // 22
            return Planning.remove(idPlanning);                                                                        // 23
        }                                                                                                              // 24
                                                                                                                       //
        return deletePlanning;                                                                                         // 16
    }(),                                                                                                               // 16
    'deletePlanningById': function () {                                                                                // 25
        function deletePlanningById(idPlanning) {                                                                      // 25
            console.log("The method 'deletePlanningById' has been called !");                                          // 26
            console.log("id objectif : " + idPlanning);                                                                // 27
                                                                                                                       //
            return Planning.remove(idPlanning);                                                                        // 29
        }                                                                                                              // 30
                                                                                                                       //
        return deletePlanningById;                                                                                     // 25
    }()                                                                                                                // 25
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"typeA":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/esp/typeA/methods.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Type Acteur                                                                                                          // 1
Meteor.methods({                                                                                                       // 2
  'addTypeA': function () {                                                                                            // 3
    function addTypeA(typeA) {                                                                                         // 3
      console.log("The method 'addTypeA' has been called !");                                                          // 4
      console.log("Type acteur : " + typeA);                                                                           // 5
                                                                                                                       //
      return TypeActeur.insert({ name: typeA });                                                                       // 7
    }                                                                                                                  // 8
                                                                                                                       //
    return addTypeA;                                                                                                   // 3
  }(),                                                                                                                 // 3
  'deleteTypeA': function () {                                                                                         // 9
    function deleteTypeA(typeAId) {                                                                                    // 9
      console.log("The method 'deleteTypeA' has been called !");                                                       // 10
      console.log("Id Type Acteur : " + typeAId);                                                                      // 11
                                                                                                                       //
      return TypeActeur.remove({ _id: typeAId });                                                                      // 13
    }                                                                                                                  // 14
                                                                                                                       //
    return deleteTypeA;                                                                                                // 9
  }()                                                                                                                  // 9
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/esp/methods.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//ESP                                                                                                                  // 1
Meteor.methods({                                                                                                       // 2
  'addEspEmpty': function () {                                                                                         // 3
    function addEspEmpty() {                                                                                           // 3
      console.log("The method 'addEspEmpty' has been called !");                                                       // 4
                                                                                                                       //
      return Esp.insert({ nomProjet: "",                                                                               // 6
        objectifs: [],                                                                                                 // 7
        enjeux: [],                                                                                                    // 8
        contexte: [],                                                                                                  // 9
        planning: [],                                                                                                  // 10
        acteurProjet: [],                                                                                              // 11
        acteurUsager: []                                                                                               // 12
      });                                                                                                              // 6
    }                                                                                                                  // 15
                                                                                                                       //
    return addEspEmpty;                                                                                                // 3
  }(),                                                                                                                 // 3
  /************************** NomProjet  ***************************/                                                  // 16
  'addNomProjetToEsp': function () {                                                                                   // 17
    function addNomProjetToEsp(idEsp, nomProjet) {                                                                     // 17
      console.log("The method 'addNomProjetToEsp' has been called !");                                                 // 18
      console.log("ID ESP : " + idEsp);                                                                                // 19
      console.log("nom Projet : " + nomProjet);                                                                        // 20
                                                                                                                       //
      Esp.update({ _id: idEsp }, { $set: { nomProjet: nomProjet } });                                                  // 22
    }                                                                                                                  // 23
                                                                                                                       //
    return addNomProjetToEsp;                                                                                          // 17
  }(),                                                                                                                 // 17
                                                                                                                       //
  /********************************Objectif ************************/                                                  // 25
  'addObjToEsp': function () {                                                                                         // 26
    function addObjToEsp(idEsp, idObjectif) {                                                                          // 26
      console.log("The method 'addObjToEsp' has been called !");                                                       // 27
      console.log("Id ESP : " + idEsp);                                                                                // 28
      console.log("Id Objectif : " + idObjectif);                                                                      // 29
                                                                                                                       //
      //Add Obj to Esp if he's not already in it                                                                       // 31
      var esp = Esp.findOne({ _id: idEsp });                                                                           // 32
      var espObjectifs = esp.objectifs;                                                                                // 33
      var i = espObjectifs.indexOf(idObjectif);                                                                        // 34
                                                                                                                       //
      if (i == -1) {                                                                                                   // 36
        espObjectifs.push(idObjectif);                                                                                 // 37
        Esp.update({ _id: idEsp }, { $set: { objectifs: espObjectifs } });                                             // 38
      }                                                                                                                // 39
    }                                                                                                                  // 41
                                                                                                                       //
    return addObjToEsp;                                                                                                // 26
  }(),                                                                                                                 // 26
                                                                                                                       //
  'deleteObjToEsp': function () {                                                                                      // 43
    function deleteObjToEsp(idEsp, idObjectif) {                                                                       // 43
      console.log("The method 'deleteObjToEsp' has been called !");                                                    // 44
      console.log("Id ESP : " + idEsp);                                                                                // 45
      console.log("Id Objectif : " + idObjectif);                                                                      // 46
                                                                                                                       //
      //Remove the objectif from the esp                                                                               // 48
      var esp = Esp.findOne({ _id: idEsp });                                                                           // 49
      var espObjectifs = esp.objectifs;                                                                                // 50
      var i = espObjectifs.indexOf(idObjectif);                                                                        // 51
                                                                                                                       //
      if (i != -1) {                                                                                                   // 53
        Meteor.call('deleteObjectifById', idObjectif);                                                                 // 54
        espObjectifs.splice(i, 1);                                                                                     // 55
        Esp.update({ _id: idEsp }, { $set: { objectifs: espObjectifs } });                                             // 56
      }                                                                                                                // 57
    }                                                                                                                  // 58
                                                                                                                       //
    return deleteObjToEsp;                                                                                             // 43
  }(),                                                                                                                 // 43
  /************************************************************************/                                           // 59
  /****************************ENJEUX  ***********************************/                                            // 60
  'addEnjToEsp': function () {                                                                                         // 61
    function addEnjToEsp(idEsp, idEnjeux) {                                                                            // 61
      console.log("The method 'addEnjToEsp' has been called !");                                                       // 62
      console.log("Id ESP : " + idEsp);                                                                                // 63
      console.log("Id Enjeux : " + idEnjeux);                                                                          // 64
                                                                                                                       //
      //Add Enj to Esp if he's not already in it                                                                       // 66
      var esp = Esp.findOne({ _id: idEsp });                                                                           // 67
      var espEnjeux = esp.enjeux;                                                                                      // 68
                                                                                                                       //
      var i = espEnjeux.indexOf(idEnjeux);                                                                             // 70
                                                                                                                       //
      if (i == -1) {                                                                                                   // 72
                                                                                                                       //
        espEnjeux.push(idEnjeux);                                                                                      // 74
        Esp.update({ _id: idEsp }, { $set: { enjeux: espEnjeux } });                                                   // 75
      }                                                                                                                // 76
    }                                                                                                                  // 77
                                                                                                                       //
    return addEnjToEsp;                                                                                                // 61
  }(),                                                                                                                 // 61
                                                                                                                       //
  'deleteEnjToEsp': function () {                                                                                      // 79
    function deleteEnjToEsp(idEsp, idEnjeux) {                                                                         // 79
      console.log("The method 'deleteEnjToEsp' has been called !");                                                    // 80
      console.log("Id ESP : " + idEsp);                                                                                // 81
      console.log("Id Enjeux : " + idEnjeux);                                                                          // 82
                                                                                                                       //
      //Remove the enjeux from the esp                                                                                 // 84
      var esp = Esp.findOne({ _id: idEsp });                                                                           // 85
      var espEnjeux = esp.enjeux;                                                                                      // 86
      var i = espEnjeux.indexOf(idEnjeux);                                                                             // 87
                                                                                                                       //
      if (i != -1) {                                                                                                   // 89
        Meteor.call('deleteEnjeuxById', idEnjeux);                                                                     // 90
        espEnjeux.splice(i, 1);                                                                                        // 91
        Esp.update({ _id: idEsp }, { $set: { enjeux: espEnjeux } });                                                   // 92
      }                                                                                                                // 93
    }                                                                                                                  // 94
                                                                                                                       //
    return deleteEnjToEsp;                                                                                             // 79
  }(),                                                                                                                 // 79
  /********************************************************************/                                               // 95
  /************************* ACTEUR USAGERS***************************/                                                // 96
  'addAUToEsp': function () {                                                                                          // 97
    function addAUToEsp(idEsp, idActeurUsager) {                                                                       // 97
      console.log("The method 'addAUToEsp' has been called !");                                                        // 98
      console.log("Id ESP : " + idEsp);                                                                                // 99
      console.log("Id Acteur Usager : " + idActeurUsager);                                                             // 100
                                                                                                                       //
      //Add Enj to Esp if he's not already in it                                                                       // 102
      var esp = Esp.findOne({ _id: idEsp });                                                                           // 103
      var espAU = esp.acteurUsager;                                                                                    // 104
                                                                                                                       //
      var i = espAU.indexOf(idActeurUsager);                                                                           // 106
                                                                                                                       //
      if (i == -1) {                                                                                                   // 108
        espAU.push(idActeurUsager);                                                                                    // 109
        Esp.update({ _id: idEsp }, { $set: { acteurUsager: espAU } });                                                 // 110
      }                                                                                                                // 111
    }                                                                                                                  // 112
                                                                                                                       //
    return addAUToEsp;                                                                                                 // 97
  }(),                                                                                                                 // 97
                                                                                                                       //
  'deleteAUToEsp': function () {                                                                                       // 114
    function deleteAUToEsp(idEsp, idActeurUsager) {                                                                    // 114
      console.log("The method 'deleteAUToEsp' has been called !");                                                     // 115
      console.log("Id ESP : " + idEsp);                                                                                // 116
      console.log("Id Enjeux : " + idActeurUsager);                                                                    // 117
                                                                                                                       //
      //Remove the enjeux from the esp                                                                                 // 119
      var esp = Esp.findOne({ _id: idEsp });                                                                           // 120
      var espAU = esp.acteurUsager;                                                                                    // 121
      var i = espAU.indexOf(idActeurUsager);                                                                           // 122
                                                                                                                       //
      if (i != -1) {                                                                                                   // 124
        Meteor.call('deleteActeurUsagerById', idActeurUsager);                                                         // 125
        espAU.splice(i, 1);                                                                                            // 126
        Esp.update({ _id: idEsp }, { $set: { acteurUsager: espAU } });                                                 // 127
      }                                                                                                                // 128
    }                                                                                                                  // 129
                                                                                                                       //
    return deleteAUToEsp;                                                                                              // 114
  }(),                                                                                                                 // 114
  /*******************************************************************/                                                // 130
  /**************************Acteur Projet****************************/                                                // 131
  'addAPToEsp': function () {                                                                                          // 132
    function addAPToEsp(idEsp, idActeurProjet) {                                                                       // 132
      console.log("The method 'addAPToEsp' has been called !");                                                        // 133
      console.log("Id ESP : " + idEsp);                                                                                // 134
      console.log("Id Acteur Projet : " + idActeurProjet);                                                             // 135
                                                                                                                       //
      //Add Enj to Esp if he's not already in it                                                                       // 137
      var esp = Esp.findOne({ _id: idEsp });                                                                           // 138
      var espAP = esp.acteurProjet;                                                                                    // 139
                                                                                                                       //
      var i = espAP.indexOf(idActeurProjet);                                                                           // 141
                                                                                                                       //
      if (i == -1) {                                                                                                   // 143
        espAP.push(idActeurProjet);                                                                                    // 144
        Esp.update({ _id: idEsp }, { $set: { acteurProjet: espAP } });                                                 // 145
      }                                                                                                                // 146
    }                                                                                                                  // 147
                                                                                                                       //
    return addAPToEsp;                                                                                                 // 132
  }(),                                                                                                                 // 132
                                                                                                                       //
  'deleteAPToEsp': function () {                                                                                       // 149
    function deleteAPToEsp(idEsp, idActeurProjet) {                                                                    // 149
      console.log("The method 'deleteAPToEsp' has been called !");                                                     // 150
      console.log("Id ESP : " + idEsp);                                                                                // 151
      console.log("Id Enjeux : " + idActeurProjet);                                                                    // 152
                                                                                                                       //
      //Remove the enjeux from the esp                                                                                 // 154
      var esp = Esp.findOne({ _id: idEsp });                                                                           // 155
      var espAP = esp.acteurProjet;                                                                                    // 156
                                                                                                                       //
      var i = espAP.indexOf(idActeurProjet);                                                                           // 158
                                                                                                                       //
      if (i != -1) {                                                                                                   // 160
        Meteor.call('deleteActeurProjetById', idActeurProjet);                                                         // 161
        espAP.splice(i, 1);                                                                                            // 162
        Esp.update({ _id: idEsp }, { $set: { acteurProjet: espAP } });                                                 // 163
      }                                                                                                                // 164
    }                                                                                                                  // 165
                                                                                                                       //
    return deleteAPToEsp;                                                                                              // 149
  }(),                                                                                                                 // 149
  /*****************************************************************/                                                  // 166
  /********************** CONTEXTE *********************************/                                                  // 167
  'addContexteToEsp': function () {                                                                                    // 168
    function addContexteToEsp(idEsp, idContexte) {                                                                     // 168
      console.log("The method 'addContexteToEsp' has been called !");                                                  // 169
      console.log("Id ESP : " + idEsp);                                                                                // 170
      console.log("Id Contexte : " + idContexte);                                                                      // 171
                                                                                                                       //
      //Add contexte to Esp if he's not already in it                                                                  // 173
      var esp = Esp.findOne({ _id: idEsp });                                                                           // 174
      var espContexte = esp.contexte;                                                                                  // 175
                                                                                                                       //
      var i = espContexte.indexOf(idContexte);                                                                         // 177
                                                                                                                       //
      if (i == -1) {                                                                                                   // 179
        espContexte.push(idContexte);                                                                                  // 180
        Esp.update({ _id: idEsp }, { $set: { contexte: espContexte } });                                               // 181
      }                                                                                                                // 182
    }                                                                                                                  // 183
                                                                                                                       //
    return addContexteToEsp;                                                                                           // 168
  }(),                                                                                                                 // 168
                                                                                                                       //
  'deleteContexteToEsp': function () {                                                                                 // 185
    function deleteContexteToEsp(idEsp, idContexte) {                                                                  // 185
      console.log("The method 'addContexteToEsp' has been called !");                                                  // 186
      console.log("Id ESP : " + idEsp);                                                                                // 187
      console.log("Id Contexte : " + idContexte);                                                                      // 188
                                                                                                                       //
      //delete contexte in Esp                                                                                         // 190
      var esp = Esp.findOne({ _id: idEsp });                                                                           // 191
      var espContexte = esp.contexte;                                                                                  // 192
                                                                                                                       //
      var i = espContexte.indexOf(idContexte);                                                                         // 194
                                                                                                                       //
      if (i != -1) {                                                                                                   // 196
        Meteor.call('deleteContexteById', idContexte);                                                                 // 197
        espContexte.splice(i, 1);                                                                                      // 198
        Esp.update({ _id: idEsp }, { $set: { contexte: espContexte } });                                               // 199
      }                                                                                                                // 200
    }                                                                                                                  // 201
                                                                                                                       //
    return deleteContexteToEsp;                                                                                        // 185
  }(),                                                                                                                 // 185
  /******************************************************************/                                                 // 202
  /*******************************Planning***************************/                                                 // 203
  'addPlanningToEsp': function () {                                                                                    // 204
    function addPlanningToEsp(idEsp, idPlanning) {                                                                     // 204
      console.log("The method 'addPlanningToEsp' has been called !");                                                  // 205
      console.log("Id ESP : " + idEsp);                                                                                // 206
      console.log("Id Planning : " + idPlanning);                                                                      // 207
                                                                                                                       //
      //Add Planning to Esp if he's not already in it                                                                  // 209
      var esp = Esp.findOne({ _id: idEsp });                                                                           // 210
      var espPlanning = esp.planning;                                                                                  // 211
                                                                                                                       //
      var i = espPlanning.indexOf(idPlanning);                                                                         // 213
                                                                                                                       //
      if (i == -1) {                                                                                                   // 215
        espPlanning.push(idPlanning);                                                                                  // 216
        Esp.update({ _id: idEsp }, { $set: { planning: espPlanning } });                                               // 217
      }                                                                                                                // 218
    }                                                                                                                  // 219
                                                                                                                       //
    return addPlanningToEsp;                                                                                           // 204
  }(),                                                                                                                 // 204
  'deletePlanningToEsp': function () {                                                                                 // 220
    function deletePlanningToEsp(idEsp, idPlanning) {                                                                  // 220
      console.log("The method 'deletePlanningToEsp' has been called !");                                               // 221
      console.log("Id ESP : " + idEsp);                                                                                // 222
      console.log("Id Planning : " + idPlanning);                                                                      // 223
                                                                                                                       //
      //delete Planning in Esp                                                                                         // 225
      var esp = Esp.findOne({ _id: idEsp });                                                                           // 226
      var espPlanning = esp.planning;                                                                                  // 227
                                                                                                                       //
      var i = espPlanning.indexOf(idPlanning);                                                                         // 229
                                                                                                                       //
      if (i != -1) {                                                                                                   // 231
        Meteor.call('deletePlanningById', idPlanning);                                                                 // 232
        espPlanning.splice(i, 1);                                                                                      // 233
        Esp.update({ _id: idEsp }, { $set: { planning: espPlanning } });                                               // 234
      }                                                                                                                // 235
    }                                                                                                                  // 236
                                                                                                                       //
    return deletePlanningToEsp;                                                                                        // 220
  }(),                                                                                                                 // 220
  /********************************************************************/                                               // 237
  'deleteEsp': function () {                                                                                           // 238
    function deleteEsp(idEsp) {                                                                                        // 238
      console.log("The method 'deleteEsp' has been called !");                                                         // 239
      console.log("ID ESP : " + idEsp);                                                                                // 240
                                                                                                                       //
      var esp = Esp.findOne({ _id: idEsp });                                                                           // 242
                                                                                                                       //
      //objectifs                                                                                                      // 244
      for (var i = 0; i < esp.objectifs.length; i++) {                                                                 // 245
        Meteor.call('deleteObjToEsp', idEsp, esp.objectifs[i]);                                                        // 246
      }                                                                                                                // 247
      //enjeux                                                                                                         // 248
      for (var i = 0; i < esp.enjeux.length; i++) {                                                                    // 249
        Meteor.call('deleteEnjToEsp', idEsp, esp.enjeux[i]);                                                           // 250
      }                                                                                                                // 251
      //acteur projet                                                                                                  // 252
      for (var i = 0; i < esp.acteurProjet.length; i++) {                                                              // 253
        Meteor.call('deleteAPToEsp', idEsp, esp.acteurProjet[i]);                                                      // 254
      }                                                                                                                // 255
      //acteur usager                                                                                                  // 256
      for (var i = 0; i < esp.acteurUsager.length; i++) {                                                              // 257
        Meteor.call('deleteAUToEsp', idEsp, esp.acteurUsager[i]);                                                      // 258
      }                                                                                                                // 259
      //contexte                                                                                                       // 260
      for (var i = 0; i < esp.contexte.length; i++) {                                                                  // 261
        Meteor.call('deleteContexteToEsp', idEsp, esp.contexte[i]);                                                    // 262
      }                                                                                                                // 263
      //planning                                                                                                       // 264
      for (var i = 0; i < esp.planning.length; i++) {                                                                  // 265
        Meteor.call('deletePlanningToEsp', idEsp, esp.planning[i]);                                                    // 266
      }                                                                                                                // 267
      return Esp.remove({ _id: idEsp });                                                                               // 268
    }                                                                                                                  // 269
                                                                                                                       //
    return deleteEsp;                                                                                                  // 238
  }()                                                                                                                  // 238
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"fsd":{"donnesMetier":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/fsd/donnesMetier/methods.js                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Donnes Metier                                                                                                        // 1
                                                                                                                       //
Meteor.methods({                                                                                                       // 3
    'addDonnesMetierEmpty': function () {                                                                              // 4
        function addDonnesMetierEmpty() {                                                                              // 4
            console.log("The method 'addDonnesMetierEmpty' has been called !");                                        // 5
                                                                                                                       //
            return DonMetier.insert({ name: "", min: false, rie: false, ext: false, pub: false, createAt: new Date() });
        }                                                                                                              // 8
                                                                                                                       //
        return addDonnesMetierEmpty;                                                                                   // 4
    }(),                                                                                                               // 4
    'updateDM': function () {                                                                                          // 9
        function updateDM(idDonMetier, name, min, rie, ext, pub) {                                                     // 9
            console.log("The method 'updateDM' has been called !");                                                    // 10
            console.log("\tid Donnees Metier :" + idDonMetier);                                                        // 11
            console.log("\tName : " + name);                                                                           // 12
            console.log("\tMin :" + min);                                                                              // 13
            console.log("\tRIE :" + rie);                                                                              // 14
            console.log("\tEXT :" + ext);                                                                              // 15
            console.log("\tPUB :" + pub);                                                                              // 16
                                                                                                                       //
            return DonMetier.update({ _id: idDonMetier }, { $set: { name: name, min: min, rie: rie, ext: ext, pub: pub } });
        }                                                                                                              // 20
                                                                                                                       //
        return updateDM;                                                                                               // 9
    }(),                                                                                                               // 9
                                                                                                                       //
    'deleteDM': function () {                                                                                          // 22
        function deleteDM(idDonMetier) {                                                                               // 22
            console.log("The method 'deleteDM' has been called !");                                                    // 23
            console.log("\tid Donnees Metier : " + idDonMetier);                                                       // 24
            Fsd.find().forEach(function (fsd) {                                                                        // 25
                Meteor.call('deleteDMToFsd', fsd._id, idDonMetier);                                                    // 26
            });                                                                                                        // 27
            return DonMetier.remove({ _id: idDonMetier });                                                             // 28
        }                                                                                                              // 29
                                                                                                                       //
        return deleteDM;                                                                                               // 22
    }(),                                                                                                               // 22
    'deleteDMById': function () {                                                                                      // 30
        function deleteDMById(idDonMetier) {                                                                           // 30
            console.log("The method 'deleteDMById' has been called !");                                                // 31
            console.log("\tid Donnees Metier : " + idDonMetier);                                                       // 32
                                                                                                                       //
            return DonMetier.remove({ _id: idDonMetier });                                                             // 34
        }                                                                                                              // 35
                                                                                                                       //
        return deleteDMById;                                                                                           // 30
    }()                                                                                                                // 30
});                                                                                                                    // 3
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"foncMetier":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/fsd/foncMetier/methods.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Fonctionnalités metier                                                                                               // 1
                                                                                                                       //
Meteor.methods({                                                                                                       // 3
    'addFoncMetierEmpty': function () {                                                                                // 4
        function addFoncMetierEmpty() {                                                                                // 4
            console.log("The method 'addFoncMetierEmpty' has been called !");                                          // 5
                                                                                                                       //
            return FoncMetier.insert({ name: "", min: false, rie: false, ext: false, pub: false, createAt: new Date() });
        }                                                                                                              // 8
                                                                                                                       //
        return addFoncMetierEmpty;                                                                                     // 4
    }(),                                                                                                               // 4
    'updateFM': function () {                                                                                          // 9
        function updateFM(idFoncMetier, name, min, rie, ext, pub) {                                                    // 9
            console.log("The method 'updateFM' has been called !");                                                    // 10
            console.log("\tid Fonctionnalités metier :" + idFoncMetier);                                               // 11
            console.log("\tName : " + name);                                                                           // 12
            console.log("\tMin :" + min);                                                                              // 13
            console.log("\tRIE :" + rie);                                                                              // 14
            console.log("\tEXT :" + ext);                                                                              // 15
            console.log("\tPUB :" + pub);                                                                              // 16
                                                                                                                       //
            return FoncMetier.update({ _id: idFoncMetier }, { $set: { name: name, min: min, rie: rie, ext: ext, pub: pub } });
        }                                                                                                              // 20
                                                                                                                       //
        return updateFM;                                                                                               // 9
    }(),                                                                                                               // 9
    'deleteFM': function () {                                                                                          // 21
        function deleteFM(idFoncMetier) {                                                                              // 21
            console.log("The method 'deleteFM' has been called !");                                                    // 22
            console.log("id Fonctionnalité Metier : " + idFoncMetier);                                                 // 23
            Fsd.find().forEach(function (fsd) {                                                                        // 24
                Meteor.call('deleteFMToFsd', fsd._id, idFoncMetier);                                                   // 25
            });                                                                                                        // 26
            return FoncMetier.remove({ _id: idFoncMetier });                                                           // 27
        }                                                                                                              // 28
                                                                                                                       //
        return deleteFM;                                                                                               // 21
    }(),                                                                                                               // 21
    'deleteFMById': function () {                                                                                      // 29
        function deleteFMById(idFoncMetier) {                                                                          // 29
            console.log("The method 'deleteFMById' has been called !");                                                // 30
            console.log("id Fonctionnalité Metier : " + idFoncMetier);                                                 // 31
                                                                                                                       //
            return FoncMetier.remove({ _id: idFoncMetier });                                                           // 33
        }                                                                                                              // 34
                                                                                                                       //
        return deleteFMById;                                                                                           // 29
    }()                                                                                                                // 29
});                                                                                                                    // 3
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"pjMetier":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/fsd/pjMetier/methods.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Pieces jointes Metier                                                                                                // 1
                                                                                                                       //
Meteor.methods({                                                                                                       // 3
    'addPjMetierEmpty': function () {                                                                                  // 4
        function addPjMetierEmpty() {                                                                                  // 4
            console.log("The method 'addPjMetierEmpty' has been called !");                                            // 5
            return PjMetier.insert({ name: "", min: false, rie: false, ext: false, pub: false, createAt: new Date() });
        }                                                                                                              // 7
                                                                                                                       //
        return addPjMetierEmpty;                                                                                       // 4
    }(),                                                                                                               // 4
    'updatePJ': function () {                                                                                          // 8
        function updatePJ(idPjMetier, name, min, rie, ext, pub) {                                                      // 8
            console.log("The method 'updatePJ' has been called !");                                                    // 9
            console.log("\tid PJ metier : " + idPjMetier);                                                             // 10
            console.log("\tName : " + name);                                                                           // 11
            console.log("\tMin :" + min);                                                                              // 12
            console.log("\tRIE :" + rie);                                                                              // 13
            console.log("\tEXT :" + ext);                                                                              // 14
            console.log("\tPUB :" + pub);                                                                              // 15
                                                                                                                       //
            return PjMetier.update({ _id: idPjMetier }, { $set: { name: name, min: min, rie: rie, ext: ext, pub: pub } });
        }                                                                                                              // 19
                                                                                                                       //
        return updatePJ;                                                                                               // 8
    }(),                                                                                                               // 8
    'deletePJ': function () {                                                                                          // 20
        function deletePJ(idPjMetier) {                                                                                // 20
            console.log("The method 'deletePJ' has been called !");                                                    // 21
            console.log("\tid Pieces Jointe Metier : " + idPjMetier);                                                  // 22
            Fsd.find().forEach(function (fsd) {                                                                        // 23
                Meteor.call('deletePjToFsd', fsd._id, idPjMetier);                                                     // 24
            });                                                                                                        // 25
            return PjMetier.remove({ _id: idPjMetier });                                                               // 26
        }                                                                                                              // 27
                                                                                                                       //
        return deletePJ;                                                                                               // 20
    }(),                                                                                                               // 20
    'deletePJById': function () {                                                                                      // 28
        function deletePJById(idPjMetier) {                                                                            // 28
            console.log("The method 'deletePJById' has been called !");                                                // 29
            console.log("\tid Pieces Jointes Metier : " + idPjMetier);                                                 // 30
                                                                                                                       //
            return PjMetier.remove({ _id: idPjMetier });                                                               // 32
        }                                                                                                              // 33
                                                                                                                       //
        return deletePJById;                                                                                           // 28
    }()                                                                                                                // 28
});                                                                                                                    // 3
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"refMetier":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/fsd/refMetier/methods.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//Referentiels metiers                                                                                                 // 1
                                                                                                                       //
Meteor.methods({                                                                                                       // 3
    'addRefDonneesEmpty': function () {                                                                                // 4
        function addRefDonneesEmpty() {                                                                                // 4
            console.log("The method 'addRefDonneesEmpty' has been called !");                                          // 5
            return RefDonnees.insert({ name: "", mode: "", min: false, rie: false, ext: false, pub: false, createAt: new Date() });
        }                                                                                                              // 7
                                                                                                                       //
        return addRefDonneesEmpty;                                                                                     // 4
    }(),                                                                                                               // 4
    'updateRD': function () {                                                                                          // 8
        function updateRD(idDonMetier, name, mode, min, rie, ext, pub) {                                               // 8
            console.log("The method 'updateRD' has been called !");                                                    // 9
            console.log("\tid Donnees metier :" + idDonMetier);                                                        // 10
            console.log("\tName : " + name);                                                                           // 11
            console.log("\tMode : " + mode);                                                                           // 12
            console.log("\tMin :" + min);                                                                              // 13
            console.log("\tRIE :" + rie);                                                                              // 14
            console.log("\tEXT :" + ext);                                                                              // 15
            console.log("\tPUB :" + pub);                                                                              // 16
                                                                                                                       //
            return RefDonnees.update({ _id: idDonMetier }, { $set: { name: name, mode: mode, min: min, rie: rie, ext: ext, pub: pub } });
        }                                                                                                              // 20
                                                                                                                       //
        return updateRD;                                                                                               // 8
    }(),                                                                                                               // 8
    'deleteRD': function () {                                                                                          // 21
        function deleteRD(idRD) {                                                                                      // 21
            console.log("The method 'deleteRD' has been called !");                                                    // 22
            console.log("\tid RD Metier : " + idRD);                                                                   // 23
            Fsd.find().forEach(function (fsd) {                                                                        // 24
                Meteor.call('deleteRDToFsd', fsd._id, idRD);                                                           // 25
            });                                                                                                        // 26
            return RefDonnees.remove({ _id: idRD });                                                                   // 27
        }                                                                                                              // 28
                                                                                                                       //
        return deleteRD;                                                                                               // 21
    }(),                                                                                                               // 21
    'deleteRDById': function () {                                                                                      // 29
        function deleteRDById(idRD) {                                                                                  // 29
            console.log("The method 'deleteRDById' has been called !");                                                // 30
            console.log("\tid RD Metier : " + idRD);                                                                   // 31
                                                                                                                       //
            return RefDonnees.remove({ _id: idRD });                                                                   // 33
        }                                                                                                              // 34
                                                                                                                       //
        return deleteRDById;                                                                                           // 29
    }()                                                                                                                // 29
});                                                                                                                    // 3
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"serviceConnexes":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/fsd/serviceConnexes/methods.js                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//service Connexes                                                                                                     // 1
Meteor.methods({                                                                                                       // 2
    'addServiceConnexeEmpty': function () {                                                                            // 3
        function addServiceConnexeEmpty() {                                                                            // 3
            console.log("The method 'addServiceConnexeEmpty' has been called !");                                      // 4
            return ServiceConnexe.insert({ name: "", mode: "", min: false, rie: false, ext: false, pub: false, createAt: new Date() });
        }                                                                                                              // 6
                                                                                                                       //
        return addServiceConnexeEmpty;                                                                                 // 3
    }(),                                                                                                               // 3
    'updateServiceConnexe': function () {                                                                              // 7
        function updateServiceConnexe(idServiceConnexe, name, mode, min, rie, ext, pub) {                              // 7
            console.log("The method 'updateServiceConnexe' has been called !");                                        // 8
            console.log("\tid Service Connexe :" + idServiceConnexe);                                                  // 9
            console.log("\tName : " + name);                                                                           // 10
            console.log("\tMode : " + mode);                                                                           // 11
            console.log("\tMin :" + min);                                                                              // 12
            console.log("\tRIE :" + rie);                                                                              // 13
            console.log("\tEXT :" + ext);                                                                              // 14
            console.log("\tPUB :" + pub);                                                                              // 15
                                                                                                                       //
            return ServiceConnexe.update({ _id: idServiceConnexe }, { $set: { name: name, mode: mode, min: min, rie: rie, ext: ext, pub: pub } });
        }                                                                                                              // 18
                                                                                                                       //
        return updateServiceConnexe;                                                                                   // 7
    }(),                                                                                                               // 7
    'deleteServiceConnexe': function () {                                                                              // 19
        function deleteServiceConnexe(idServiceConnexe) {                                                              // 19
            console.log("The method 'deleteServiceConnexe' has been called !");                                        // 20
            console.log("\tid Service Connexe : " + idServiceConnexe);                                                 // 21
            Fsd.find().forEach(function (fsd) {                                                                        // 22
                Meteor.call('deleteServiceConnexeToFsd', fsd._id, idServiceConnexe);                                   // 23
            });                                                                                                        // 24
            return ServiceConnexe.remove({ _id: idServiceConnexe });                                                   // 25
        }                                                                                                              // 26
                                                                                                                       //
        return deleteServiceConnexe;                                                                                   // 19
    }(),                                                                                                               // 19
    'deleteServiceConnexeById': function () {                                                                          // 27
        function deleteServiceConnexeById(idServiceConnexe) {                                                          // 27
            console.log("The method 'deleteServiceConnexeById' has been called !");                                    // 28
            console.log("\tid Service Connexe : " + idServiceConnexe);                                                 // 29
            return ServiceConnexe.remove({ _id: idServiceConnexe });                                                   // 30
        }                                                                                                              // 31
                                                                                                                       //
        return deleteServiceConnexeById;                                                                               // 27
    }()                                                                                                                // 27
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/fsd/methods.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//FSD                                                                                                                  // 1
Meteor.methods({                                                                                                       // 2
    'addFsdEmpty': function () {                                                                                       // 3
        function addFsdEmpty() {                                                                                       // 3
            console.log("The method 'addEspEmpty' has been called !");                                                 // 4
                                                                                                                       //
            return Fsd.insert({ foncMetier: [],                                                                        // 6
                donnMetier: [],                                                                                        // 7
                pjMetier: [],                                                                                          // 8
                refDonnees: [],                                                                                        // 9
                serviceConnexe: []                                                                                     // 10
            });                                                                                                        // 6
        }                                                                                                              // 12
                                                                                                                       //
        return addFsdEmpty;                                                                                            // 3
    }(),                                                                                                               // 3
    // FONCTIONNALITES METIER                                                                                          // 13
    'addFMToFsd': function () {                                                                                        // 14
        function addFMToFsd(idFsd, idFM) {                                                                             // 14
            console.log("The method 'addFMToFsd' has been called !");                                                  // 15
            console.log("id FSD : " + idFsd);                                                                          // 16
            console.log("id FM : " + idFM);                                                                            // 17
                                                                                                                       //
            var fm = Fsd.findOne({ _id: idFsd });                                                                      // 19
            var fsdFoncMetier = fm.foncMetier;                                                                         // 20
            var i = fsdFoncMetier.indexOf(idFM);                                                                       // 21
                                                                                                                       //
            if (i == -1) {                                                                                             // 23
                fsdFoncMetier.push(idFM);                                                                              // 24
                Fsd.update({ _id: idFsd }, { $set: { foncMetier: fsdFoncMetier } });                                   // 25
            }                                                                                                          // 26
        }                                                                                                              // 27
                                                                                                                       //
        return addFMToFsd;                                                                                             // 14
    }(),                                                                                                               // 14
    'deleteFMToFsd': function () {                                                                                     // 28
        function deleteFMToFsd(idFsd, idFM) {                                                                          // 28
            console.log("The method 'addFMToFsd' has been called !");                                                  // 29
            console.log("id FSD : " + idFsd);                                                                          // 30
            console.log("id FM : " + idFM);                                                                            // 31
                                                                                                                       //
            var fm = Fsd.findOne({ _id: idFsd });                                                                      // 33
            var fsdFoncMetier = fm.foncMetier;                                                                         // 34
            var i = fsdFoncMetier.indexOf(idFM);                                                                       // 35
                                                                                                                       //
            if (i != -1) {                                                                                             // 37
                Meteor.call('deleteFMById', idFM);                                                                     // 38
                fsdFoncMetier.splice(i, 1);                                                                            // 39
                Fsd.update({ _id: idFsd }, { $set: { foncMetier: fsdFoncMetier } });                                   // 40
            }                                                                                                          // 41
        }                                                                                                              // 42
                                                                                                                       //
        return deleteFMToFsd;                                                                                          // 28
    }(),                                                                                                               // 28
    // DONNEES METIER                                                                                                  // 43
    'addDMToFsd': function () {                                                                                        // 44
        function addDMToFsd(idFsd, idDM) {                                                                             // 44
            console.log("The method 'addDMToFsd' has been called !");                                                  // 45
            console.log("id FSD : " + idFsd);                                                                          // 46
            console.log("id DM : " + idDM);                                                                            // 47
                                                                                                                       //
            var fm = Fsd.findOne({ _id: idFsd });                                                                      // 49
            var fsdDonnMetier = fm.donnMetier;                                                                         // 50
            var i = fsdDonnMetier.indexOf(idDM);                                                                       // 51
                                                                                                                       //
            if (i == -1) {                                                                                             // 53
                fsdDonnMetier.push(idDM);                                                                              // 54
                Fsd.update({ _id: idFsd }, { $set: { donnMetier: fsdDonnMetier } });                                   // 55
            }                                                                                                          // 56
        }                                                                                                              // 57
                                                                                                                       //
        return addDMToFsd;                                                                                             // 44
    }(),                                                                                                               // 44
    'deleteDMToFsd': function () {                                                                                     // 58
        function deleteDMToFsd(idFsd, idDM) {                                                                          // 58
            console.log("The method 'deleteDMToFsd' has been called !");                                               // 59
            console.log("id FSD : " + idFsd);                                                                          // 60
            console.log("id DM : " + idDM);                                                                            // 61
                                                                                                                       //
            var fm = Fsd.findOne({ _id: idFsd });                                                                      // 63
            var fsdDonnMetier = fm.donnMetier;                                                                         // 64
            var i = fsdDonnMetier.indexOf(idDM);                                                                       // 65
                                                                                                                       //
            if (i != -1) {                                                                                             // 67
                Meteor.call('deleteDMById', idDM);                                                                     // 68
                fsdDonnMetier.splice(i, 1);                                                                            // 69
                Fsd.update({ _id: idFsd }, { $set: { donnMetier: fsdDonnMetier } });                                   // 70
            }                                                                                                          // 71
        }                                                                                                              // 72
                                                                                                                       //
        return deleteDMToFsd;                                                                                          // 58
    }(),                                                                                                               // 58
    //Pieces jointes Metier                                                                                            // 73
    'addPjToFsd': function () {                                                                                        // 74
        function addPjToFsd(idFsd, idPj) {                                                                             // 74
            console.log("The method 'addPjToFsd' has been called !");                                                  // 75
            console.log("id FSD : " + idFsd);                                                                          // 76
            console.log("id PJ : " + idPj);                                                                            // 77
                                                                                                                       //
            var fm = Fsd.findOne({ _id: idFsd });                                                                      // 79
            var fspjMetier = fm.pjMetier;                                                                              // 80
            var i = fspjMetier.indexOf(idPj);                                                                          // 81
                                                                                                                       //
            if (i == -1) {                                                                                             // 83
                fspjMetier.push(idPj);                                                                                 // 84
                Fsd.update({ _id: idFsd }, { $set: { pjMetier: fspjMetier } });                                        // 85
            }                                                                                                          // 86
        }                                                                                                              // 87
                                                                                                                       //
        return addPjToFsd;                                                                                             // 74
    }(),                                                                                                               // 74
    'deletePjToFsd': function () {                                                                                     // 88
        function deletePjToFsd(idFsd, idPj) {                                                                          // 88
            console.log("The method 'deletePjToFsd' has been called !");                                               // 89
            console.log("id FSD : " + idFsd);                                                                          // 90
            console.log("id PJ : " + idPj);                                                                            // 91
                                                                                                                       //
            var fm = Fsd.findOne({ _id: idFsd });                                                                      // 93
            var fspjMetier = fm.pjMetier;                                                                              // 94
            var i = fspjMetier.indexOf(idPj);                                                                          // 95
                                                                                                                       //
            if (i != -1) {                                                                                             // 97
                Meteor.call('deletePJById', idPj);                                                                     // 98
                fspjMetier.splice(i, 1);                                                                               // 99
                Fsd.update({ _id: idFsd }, { $set: { pjMetier: fspjMetier } });                                        // 100
            }                                                                                                          // 101
        }                                                                                                              // 102
                                                                                                                       //
        return deletePjToFsd;                                                                                          // 88
    }(),                                                                                                               // 88
    //Referentiels donnees                                                                                             // 103
    'addRDToFsd': function () {                                                                                        // 104
        function addRDToFsd(idFsd, idRD) {                                                                             // 104
            console.log("The method 'addRDToFsd' has been called !");                                                  // 105
            console.log("id FSD : " + idFsd);                                                                          // 106
            console.log("id RD : " + idRD);                                                                            // 107
                                                                                                                       //
            var fm = Fsd.findOne({ _id: idFsd });                                                                      // 109
            var fsrefDonnees = fm.refDonnees;                                                                          // 110
            var i = fsrefDonnees.indexOf(idRD);                                                                        // 111
                                                                                                                       //
            if (i == -1) {                                                                                             // 113
                fsrefDonnees.push(idRD);                                                                               // 114
                Fsd.update({ _id: idFsd }, { $set: { refDonnees: fsrefDonnees } });                                    // 115
            }                                                                                                          // 116
        }                                                                                                              // 117
                                                                                                                       //
        return addRDToFsd;                                                                                             // 104
    }(),                                                                                                               // 104
    'deleteRDToFsd': function () {                                                                                     // 118
        function deleteRDToFsd(idFsd, idRD) {                                                                          // 118
            console.log("The method 'deleteRDToFsd' has been called !");                                               // 119
            console.log("id FSD : " + idFsd);                                                                          // 120
            console.log("id RD : " + idRD);                                                                            // 121
                                                                                                                       //
            var fm = Fsd.findOne({ _id: idFsd });                                                                      // 123
            var fsrefDonnees = fm.refDonnees;                                                                          // 124
            var i = fsrefDonnees.indexOf(idRD);                                                                        // 125
                                                                                                                       //
            if (i != -1) {                                                                                             // 127
                Meteor.call('deleteRDById', idRD);                                                                     // 128
                fsrefDonnees.splice(i, 1);                                                                             // 129
                Fsd.update({ _id: idFsd }, { $set: { refDonnees: fsrefDonnees } });                                    // 130
            }                                                                                                          // 131
        }                                                                                                              // 132
                                                                                                                       //
        return deleteRDToFsd;                                                                                          // 118
    }(),                                                                                                               // 118
    /******************************************************************************/                                   // 133
    /******************************Service Connexe ********************************/                                   // 134
    'addServiceConnexeToFsd': function () {                                                                            // 135
        function addServiceConnexeToFsd(idFsd, idServiceConnexe) {                                                     // 135
            console.log("The method 'addServiceConnexeToFsd' has been called !");                                      // 136
            console.log("\tid FSD : " + idFsd);                                                                        // 137
            console.log("\tid Service Connexes : " + idServiceConnexe);                                                // 138
                                                                                                                       //
            var fm = Fsd.findOne({ _id: idFsd });                                                                      // 140
            var fsdServiceConnexe = fm.serviceConnexe;                                                                 // 141
            var i = fsdServiceConnexe.indexOf(idServiceConnexe);                                                       // 142
                                                                                                                       //
            if (i == -1) {                                                                                             // 144
                fsdServiceConnexe.push(idServiceConnexe);                                                              // 145
                Fsd.update({ _id: idFsd }, { $set: { serviceConnexe: fsdServiceConnexe } });                           // 146
            }                                                                                                          // 147
        }                                                                                                              // 148
                                                                                                                       //
        return addServiceConnexeToFsd;                                                                                 // 135
    }(),                                                                                                               // 135
    'deleteServiceConnexeToFsd': function () {                                                                         // 149
        function deleteServiceConnexeToFsd(idFsd, idServiceConnexe) {                                                  // 149
            console.log("The method 'deleteServiceConnexeToFsd' has been called !");                                   // 150
            console.log("\tid FSD : " + idFsd);                                                                        // 151
            console.log("\tid Service Connexes : " + idServiceConnexe);                                                // 152
                                                                                                                       //
            var fm = Fsd.findOne({ _id: idFsd });                                                                      // 154
            var fsdServiceConnexe = fm.serviceConnexe;                                                                 // 155
            var i = fsdServiceConnexe.indexOf(idServiceConnexe);                                                       // 156
                                                                                                                       //
            if (i != -1) {                                                                                             // 158
                Meteor.call('deleteServiceConnexeById', idServiceConnexe);                                             // 159
                fsdServiceConnexe.splice(i, 1);                                                                        // 160
                Fsd.update({ _id: idFsd }, { $set: { serviceConnexe: fsdServiceConnexe } });                           // 161
            }                                                                                                          // 162
        }                                                                                                              // 163
                                                                                                                       //
        return deleteServiceConnexeToFsd;                                                                              // 149
    }(),                                                                                                               // 149
    /*****************************************************************************/                                    // 164
                                                                                                                       //
    'deleteFsd': function () {                                                                                         // 166
        function deleteFsd(idFsd) {                                                                                    // 166
            console.log("The method 'deleteFsd' has been called !");                                                   // 167
            console.log("ID ESP : " + idFsd);                                                                          // 168
                                                                                                                       //
            var fsd = Fsd.findOne({ _id: idFsd });                                                                     // 170
            //Fonctionnalités métier                                                                                   // 171
            for (var i = 0; i < fsd.foncMetier.length; i++) {                                                          // 172
                Meteor.call('deleteFMToFsd', idFsd, fsd.foncMetier[i]);                                                // 173
            }                                                                                                          // 174
            //données Metier                                                                                           // 175
            for (i = 0; i < fsd.donnMetier.length; i++) {                                                              // 176
                Meteor.call('deleteDMToFsd', idFsd, fsd.donnMetier[i]);                                                // 177
            }                                                                                                          // 178
            //pieces jointes                                                                                           // 179
            for (i = 0; i < fsd.pjMetier.length; i++) {                                                                // 180
                Meteor.call('deletePjToFsd', idFsd, fsd.pjMetier[i]);                                                  // 181
            }                                                                                                          // 182
            //Referenetiels données                                                                                    // 183
            for (i = 0; i < fsd.refDonnees.length; i++) {                                                              // 184
                Meteor.call('deleteRDToFsd', idFsd, fsd.refDonnees[i]);                                                // 185
            }                                                                                                          // 186
            //service Connexe                                                                                          // 187
            for (i = 0; i < fsd.serviceConnexe.length; i++) {                                                          // 188
                Meteor.call('deleteServiceConnexeToFsd', idFsd, fsd.serviceConnexe[i]);                                // 189
            }                                                                                                          // 190
            return Fsd.remove({ _id: idFsd });                                                                         // 191
        }                                                                                                              // 192
                                                                                                                       //
        return deleteFsd;                                                                                              // 166
    }()                                                                                                                // 166
});                                                                                                                    // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"dat":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/dat/dat/methods.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({                                                                                                       // 1
    'addDat': function () {                                                                                            // 2
        function addDat(datname, userId) {                                                                             // 2
            console.log("The method 'addDat' has been called !");                                                      // 3
            console.log("Name Dat : " + datname);                                                                      // 4
                                                                                                                       //
            var idEsp = Meteor.call('addEspEmpty');                                                                    // 6
            var idCrt = Meteor.call('addCrtEmpty');                                                                    // 7
            var idFsd = Meteor.call('addFsdEmpty');                                                                    // 8
            var idEnf = Meteor.call('addEnfEmpty');                                                                    // 9
                                                                                                                       //
            var dat = Dat.insert({                                                                                     // 11
                name: datname,                                                                                         // 12
                idEsp: idEsp,                                                                                          // 13
                idFsd: idFsd,                                                                                          // 14
                idCrt: idCrt,                                                                                          // 15
                idEnf: idEnf,                                                                                          // 16
                userId: userId                                                                                         // 17
            });                                                                                                        // 11
            Meteor.call('addDatToUser', dat, userId);                                                                  // 19
        }                                                                                                              // 20
                                                                                                                       //
        return addDat;                                                                                                 // 2
    }(),                                                                                                               // 2
    'deleteDat': function () {                                                                                         // 21
        function deleteDat(idDat) {                                                                                    // 21
            console.log("The method 'deleteDat' has been called !");                                                   // 22
            console.log("Id DAT : " + idDat);                                                                          // 23
            var dat = Dat.findOne({ _id: idDat });                                                                     // 24
            // A completer pour supprimer un ESP, un projet, un fonc, une contrainte et exigences non fonctionnelles   // 25
            Meteor.call('deleteEsp', dat.idEsp);                                                                       // 26
            Meteor.call('deleteCrt', dat.idCrt);                                                                       // 27
            Meteor.call('deleteEnf', dat.idEnf);                                                                       // 28
            Meteor.call('deleteFsd', dat.idFsd);                                                                       // 29
                                                                                                                       //
            return Dat.remove({ _id: idDat });                                                                         // 31
        }                                                                                                              // 32
                                                                                                                       //
        return deleteDat;                                                                                              // 21
    }()                                                                                                                // 21
                                                                                                                       //
});                                                                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"users":{"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/users/methods.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({                                                                                                       // 1
  'setUserRole': function () {                                                                                         // 2
    function setUserRole(userId, roleId) {                                                                             // 2
      console.log("The method 'setUserRole' has been called !");                                                       // 3
      console.log("\tUser Id : " + userId);                                                                            // 4
      console.log("`\tRole Id : " + roleId);                                                                           // 5
                                                                                                                       //
      var role = Roles.findOne({ _id: roleId });                                                                       // 7
      if (role) {                                                                                                      // 8
        Meteor.users.update({ _id: userId }, { $set: { 'profile.role': role.displayName } });                          // 9
      }                                                                                                                // 10
    }                                                                                                                  // 11
                                                                                                                       //
    return setUserRole;                                                                                                // 2
  }(),                                                                                                                 // 2
  'addDatToUser': function () {                                                                                        // 12
    function addDatToUser(datId, userId) {                                                                             // 12
      console.log("The method 'addDatToUser' has been called !");                                                      // 13
      console.log("\tdat ID : " + datId);                                                                              // 14
      console.log("\tUser ID : " + userId);                                                                            // 15
                                                                                                                       //
      // Add the course to the user which is a teacher                                                                 // 17
      var user = Meteor.users.findOne({ _id: userId });                                                                // 18
      if (user) {                                                                                                      // 19
        var dats = user.profile.dats;                                                                                  // 20
        var i = dats.indexOf(datId);                                                                                   // 21
        if (i == -1) {                                                                                                 // 22
          dats.push(datId);                                                                                            // 23
          Meteor.users.update({ _id: userId }, { $set: { 'profile.dats': dats } });                                    // 24
        }                                                                                                              // 25
      }                                                                                                                // 26
    }                                                                                                                  // 27
                                                                                                                       //
    return addDatToUser;                                                                                               // 12
  }(),                                                                                                                 // 12
                                                                                                                       //
  'removeDatFromUser': function () {                                                                                   // 29
    function removeDatFromUser(datId, userId) {                                                                        // 29
      console.log("The method 'removeDatFromUser' has been called !");                                                 // 30
      console.log("\tdat ID : " + datId);                                                                              // 31
      console.log("\tUser ID : " + userId);                                                                            // 32
                                                                                                                       //
      // Add the course to the user which is a teacher                                                                 // 34
      var user = Meteor.users.findOne({ _id: userId });                                                                // 35
      if (user) {                                                                                                      // 36
        var dats = user.profile.dats;                                                                                  // 37
        var i = dats.indexOf(datId);                                                                                   // 38
        if (i != -1) {                                                                                                 // 39
          dats.split(i, 1);                                                                                            // 40
          Meteor.users.update({ _id: userId }, { $set: { 'profile.dats': dats } });                                    // 41
        }                                                                                                              // 42
      }                                                                                                                // 43
    }                                                                                                                  // 44
                                                                                                                       //
    return removeDatFromUser;                                                                                          // 29
  }(),                                                                                                                 // 29
  'setRoleDisplayName': function () {                                                                                  // 45
    function setRoleDisplayName(roleId, displayName) {                                                                 // 45
      console.log("The method 'setRoleDisplayName' has been called !");                                                // 46
      console.log("\tRole ID : " + roleId);                                                                            // 47
      console.log("\tDisplay name: " + displayName);                                                                   // 48
                                                                                                                       //
      Roles.update({ _id: roleId }, { $set: { displayName: displayName } });                                           // 50
    }                                                                                                                  // 51
                                                                                                                       //
    return setRoleDisplayName;                                                                                         // 45
  }(),                                                                                                                 // 45
  'createUserFromAdmin': function () {                                                                                 // 52
    function createUserFromAdmin(data) {                                                                               // 52
      console.log("The method 'createUserFromAdmin' has been called !");                                               // 53
      Accounts.createUser(data);                                                                                       // 54
    }                                                                                                                  // 55
                                                                                                                       //
    return createUserFromAdmin;                                                                                        // 52
  }(),                                                                                                                 // 52
  'updateProfile': function () {                                                                                       // 56
    function updateProfile(userId, firstname, lastname, email) {                                                       // 56
      console.log("The method 'updateProfile' has been called !");                                                     // 57
      Meteor.users.update({ _id: userId }, { $set: { 'profile.firstname': firstname, 'profile.lastname': lastname, 'profile.email': email } });
    }                                                                                                                  // 59
                                                                                                                       //
    return updateProfile;                                                                                              // 56
  }()                                                                                                                  // 56
});                                                                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"startup":{"startup.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/startup/startup.js                                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(function () {                                                                                           // 1
    if (Roles.find().count() === 0) {                                                                                  // 2
        Roles.insert({ displayName: 'attente' });                                                                      // 3
        Roles.insert({ displayName: 'contributeur' });                                                                 // 4
        Roles.insert({ displayName: 'admin' });                                                                        // 5
    }                                                                                                                  // 6
    if (TypeActeur.find().count() === 0) {                                                                             // 7
        TypeActeur.insert({ name: 'MITECH' });                                                                         // 8
        TypeActeur.insert({ name: 'MIPIL' });                                                                          // 9
        TypeActeur.insert({ name: 'MOA' });                                                                            // 10
        TypeActeur.insert({ name: 'AMOA' });                                                                           // 11
        TypeActeur.insert({ name: 'MOE' });                                                                            // 12
        TypeActeur.insert({ name: 'AMOE' });                                                                           // 13
        TypeActeur.insert({ name: 'PRESTA' });                                                                         // 14
        TypeActeur.insert({ name: 'INTEG' });                                                                          // 15
    }                                                                                                                  // 16
    if (Meteor.users.find().count() === 0) {                                                                           // 17
        var data = {                                                                                                   // 18
            username: "dsimitech",                                                                                     // 19
            password: "Mitech2016!",                                                                                   // 20
            profile: {                                                                                                 // 21
                firstname: "",                                                                                         // 22
                lastname: "",                                                                                          // 23
                email: "",                                                                                             // 24
                role: "admin",                                                                                         // 25
                dats: []                                                                                               // 26
            }                                                                                                          // 21
        };                                                                                                             // 18
        Accounts.createUser(data);                                                                                     // 29
    }                                                                                                                  // 30
    if (TypePostdTravail.find().count() === 0) {                                                                       // 31
        TypePostdTravail.insert({ name: 'Bureautique' });                                                              // 32
        TypePostdTravail.insert({ name: 'Navigateur' });                                                               // 33
        TypePostdTravail.insert({ name: 'Périphérique' });                                                             // 34
        TypePostdTravail.insert({ name: 'Système exploitation' });                                                     // 35
        TypePostdTravail.insert({ name: 'Autre' });                                                                    // 36
    }                                                                                                                  // 37
    if (TypecritExigence.find().count() === 0) {                                                                       // 38
        TypecritExigence.insert({ name: 'Exigence intégrité' });                                                       // 39
        TypecritExigence.insert({ name: 'Exigence confidentialité' });                                                 // 40
        TypecritExigence.insert({ name: 'Exigence preuve' });                                                          // 41
        TypecritExigence.insert({ name: 'Exigence traçabilité' });                                                     // 42
    }                                                                                                                  // 43
    if (CritTypePerfPeriode.find().count() === 0) {                                                                    // 44
        CritTypePerfPeriode.insert({ name: 'Standard' });                                                              // 45
        CritTypePerfPeriode.insert({ name: 'Critique' });                                                              // 46
        CritTypePerfPeriode.insert({ name: 'Charge' });                                                                // 47
    }                                                                                                                  // 49
    if (CritTypeAppMetier.find().count() === 0) {                                                                      // 50
        CritTypeAppMetier.insert({ name: "Plage Services intogérance" });                                              // 51
        CritTypeAppMetier.insert({ name: "Perte de Données Maximale Admissible" });                                    // 52
        CritTypeAppMetier.insert({ name: "Durée Maximale d'interruption Admissible" });                                // 53
    }                                                                                                                  // 54
    if (CritTypeTempsReponse.find().count() === 0) {                                                                   // 55
        CritTypeTempsReponse.insert({ name: "Affichage page d'accueil" });                                             // 56
        CritTypeTempsReponse.insert({ name: "Affichage page simple" });                                                // 57
        CritTypeTempsReponse.insert({ name: "Affichage page complexe" });                                              // 58
        CritTypeTempsReponse.insert({ name: "Traitement requête simple" });                                            // 59
        CritTypeTempsReponse.insert({ name: "Traitement requête complexe" });                                          // 60
    }                                                                                                                  // 61
    if (TypecritImpact.find().count() === 0) {                                                                         // 62
        TypecritImpact.insert({ name: "Impact Métier" });                                                              // 63
        TypecritImpact.insert({ name: "Impact Charge" });                                                              // 64
    }                                                                                                                  // 65
});                                                                                                                    // 68
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},{"extensions":[".js",".json"]});
require("./lib/routers/logged/admin/typeAU/route.js");
require("./lib/routers/logged/admin/user/route.js");
require("./lib/routers/logged/admin/route.js");
require("./lib/routers/logged/attente/route.js");
require("./lib/routers/logged/contributeur/route.js");
require("./lib/routers/logged/unlogged/route.js");
require("./lib/collections/crt/RedVol.js");
require("./lib/collections/crt/VolDonnee.js");
require("./lib/collections/crt/crt.js");
require("./lib/collections/crt/dependance.js");
require("./lib/collections/crt/hebergement.js");
require("./lib/collections/crt/posttravail.js");
require("./lib/collections/crt/reglementaire.js");
require("./lib/collections/crt/securite.js");
require("./lib/collections/crt/typepdt.js");
require("./lib/collections/crt/volFichier.js");
require("./lib/collections/crt/volumetrie.js");
require("./lib/collections/enf/critDispo.js");
require("./lib/collections/enf/critDispoAppMetier.js");
require("./lib/collections/enf/critDispoPeriode.js");
require("./lib/collections/enf/critExploi.js");
require("./lib/collections/enf/critExploiBatch.js");
require("./lib/collections/enf/critExploiImpact.js");
require("./lib/collections/enf/critPerformance.js");
require("./lib/collections/enf/critSecuExigence.js");
require("./lib/collections/enf/critSecurite.js");
require("./lib/collections/enf/critTypeAppMetier.js");
require("./lib/collections/enf/critTypePerfPeriode.js");
require("./lib/collections/enf/critTypeTemps.js");
require("./lib/collections/enf/enf.js");
require("./lib/collections/enf/typeCritImpact.js");
require("./lib/collections/enf/typeSecuExigence.js");
require("./lib/collections/esp/Enjeux.js");
require("./lib/collections/esp/Objectifs.js");
require("./lib/collections/esp/TypeActeur.js");
require("./lib/collections/esp/acteurProjet.js");
require("./lib/collections/esp/acteurUsager.js");
require("./lib/collections/esp/contexte.js");
require("./lib/collections/esp/esp.js");
require("./lib/collections/esp/planning.js");
require("./lib/collections/fsd/donMetier.js");
require("./lib/collections/fsd/foncMetier.js");
require("./lib/collections/fsd/fsd.js");
require("./lib/collections/fsd/pjMetier.js");
require("./lib/collections/fsd/refDonnees.js");
require("./lib/collections/fsd/serviceConnexe.js");
require("./lib/collections/user/role.js");
require("./lib/routers/crt/route.js");
require("./lib/routers/dat/route.js");
require("./lib/routers/enf/route.js");
require("./lib/routers/esp/route.js");
require("./lib/routers/fsd/route.js");
require("./lib/routers/home/route.js");
require("./lib/routers/login/route.js");
require("./lib/routers/register/route.js");
require("./lib/collections/dat.js");
require("./lib/routers/route.js");
require("./server/methods/dat/enf/critDispo/appmetier/typeappmetier/methods.js");
require("./server/methods/dat/enf/critDispo/periode/typeperiode/methods.js");
require("./server/methods/dat/enf/critExploit/impact/typeImpact/methods.js");
require("./server/methods/dat/enf/critSecurit/exigence/typeExigence/methods.js");
require("./server/methods/dat/crt/postedetravail/typePostedetravail/methods.js");
require("./server/methods/dat/crt/volumetrie/donnees/methods.js");
require("./server/methods/dat/crt/volumetrie/fichiers/methods.js");
require("./server/methods/dat/crt/volumetrie/reduction/methods.js");
require("./server/methods/dat/enf/critDispo/appmetier/methods.js");
require("./server/methods/dat/enf/critDispo/periode/methods.js");
require("./server/methods/dat/enf/critExploit/batch/methods.js");
require("./server/methods/dat/enf/critExploit/impact/methods.js");
require("./server/methods/dat/enf/critPerfor/typeTempsdereponse/methods.js");
require("./server/methods/dat/enf/critSecurit/exigence/methods.js");
require("./server/methods/dat/crt/dependance/methods.js");
require("./server/methods/dat/crt/hebergement/methods.js");
require("./server/methods/dat/crt/postedetravail/methods.js");
require("./server/methods/dat/crt/reglementaire/methods.js");
require("./server/methods/dat/crt/securite/methods.js");
require("./server/methods/dat/crt/volumetrie/methods.js");
require("./server/methods/dat/enf/critDispo/methods.js");
require("./server/methods/dat/enf/critExploit/methods.js");
require("./server/methods/dat/enf/critPerfor/methods.js");
require("./server/methods/dat/enf/critSecurit/methods.js");
require("./server/methods/dat/esp/Enjeux/methods.js");
require("./server/methods/dat/esp/Objectifs/methods.js");
require("./server/methods/dat/esp/acteurProjet/methods.js");
require("./server/methods/dat/esp/acteurUsager/methods.js");
require("./server/methods/dat/esp/contexte/methods.js");
require("./server/methods/dat/esp/planningProjet/methods.js");
require("./server/methods/dat/esp/typeA/methods.js");
require("./server/methods/dat/fsd/donnesMetier/methods.js");
require("./server/methods/dat/fsd/foncMetier/methods.js");
require("./server/methods/dat/fsd/pjMetier/methods.js");
require("./server/methods/dat/fsd/refMetier/methods.js");
require("./server/methods/dat/fsd/serviceConnexes/methods.js");
require("./server/methods/dat/crt/methods.js");
require("./server/methods/dat/dat/methods.js");
require("./server/methods/dat/enf/methods.js");
require("./server/methods/dat/esp/methods.js");
require("./server/methods/dat/fsd/methods.js");
require("./server/methods/users/methods.js");
require("./server/startup/startup.js");
//# sourceMappingURL=app.js.map
